@echo off
adb devices
adb forward tcp:4747 tcp:4747
python test_receiver.py 127.0.0.1 usb_capture.h264
