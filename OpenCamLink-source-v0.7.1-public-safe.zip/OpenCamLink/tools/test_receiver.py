#!/usr/bin/env python3
"""Minimal interoperability test receiver for OpenCam Link.
Connects to the Android server, requests AVC 1920x1080, and writes raw H.264.
Usage: python test_receiver.py PHONE_IP [output.h264]
For USB after `adb forward tcp:4747 tcp:4747`, use 127.0.0.1.
"""
import socket, struct, sys
host = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
out_name = sys.argv[2] if len(sys.argv) > 2 else "capture.h264"
req = (
    "GET /v5/video/avc/1920x1080/port/0/os/windows/obs//client//hdr/0/nonce/5912/ HTTP/1.1\r\n"
    f"Host: {host}:4747\r\nConnection: close\r\n\r\n"
).encode("ascii")
with socket.create_connection((host, 4747), timeout=10) as s, open(out_name, "wb") as f:
    s.sendall(req)
    buf = b""
    while b"\r\n\r\n" not in buf:
        part = s.recv(4096)
        if not part: raise SystemExit("connection closed before HTTP response")
        buf += part
    headers, remain = buf.split(b"\r\n\r\n", 1)
    print(headers.decode("latin1"))
    pending = bytearray(remain)
    def readn(n):
        while len(pending) < n:
            part = s.recv(max(4096, n-len(pending)))
            if not part: raise EOFError
            pending.extend(part)
        data = bytes(pending[:n]); del pending[:n]; return data
    frames = 0
    try:
        while True:
            pts, size = struct.unpack(">QI", readn(12))
            payload = readn(size)
            f.write(payload)
            frames += 1
            if frames % 60 == 0: print(f"frames={frames} pts={pts} size={size}")
    except EOFError:
        pass
print(f"saved {frames} packets to {out_name}")
