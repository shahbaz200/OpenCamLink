package com.opencamlink;

import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

final class ClientWriter implements Runnable {
    private static final String TAG = "OpenCamLink.Client";
    private final Socket socket;
    private final BufferedOutputStream out;
    private final ArrayBlockingQueue<Frame> queue = new ArrayBlockingQueue<>(10);
    private volatile boolean running = true;

    ClientWriter(Socket socket) throws IOException {
        this.socket = socket;
        this.out = new BufferedOutputStream(socket.getOutputStream(), 256 * 1024);
    }

    void enqueue(Frame frame) {
        if (!running) return;
        if (!queue.offer(frame)) {
            queue.poll();
            queue.offer(frame);
        }
    }

    void close() {
        running = false;
        try { socket.close(); } catch (IOException ignored) {}
    }

    @Override public void run() {
        try {
            while (running) {
                Frame f = queue.poll(1, TimeUnit.SECONDS);
                if (f == null) continue;
                Protocol.writeFrame(out, f.config ? -1L : f.ptsUs, f.data);
                out.flush();
            }
        } catch (Exception e) {
            Log.i(TAG, "client disconnected: " + e.getMessage());
        } finally {
            close();
        }
    }
}
