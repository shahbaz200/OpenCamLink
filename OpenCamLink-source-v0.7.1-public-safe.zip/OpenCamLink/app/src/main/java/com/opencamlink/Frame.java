package com.opencamlink;

final class Frame {
    final long ptsUs;
    final byte[] data;
    final boolean config;
    final boolean keyFrame;

    Frame(long ptsUs, byte[] data, boolean config, boolean keyFrame) {
        this.ptsUs = ptsUs;
        this.data = data;
        this.config = config;
        this.keyFrame = keyFrame;
    }
}
