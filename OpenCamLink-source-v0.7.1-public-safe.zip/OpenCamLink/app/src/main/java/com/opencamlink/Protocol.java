package com.opencamlink;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * Minimal clean-room compatibility framing for the public OBS receiver protocol.
 * The OBS receiver expects the video socket to become raw binary immediately after
 * its GET request; there is no HTTP response header.
 * Frame: 8-byte big-endian PTS + 4-byte big-endian payload length + payload.
 * A codec-config packet uses PTS = UINT64_MAX, represented by Java long -1.
 */
final class Protocol {
    private Protocol() {}

    static void writeHttpOk(OutputStream out) throws IOException {
        String h = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/octet-stream\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    static void writeHttpError(OutputStream out, int code, String msg) throws IOException {
        String body = msg + "\n";
        String h = "HTTP/1.1 " + code + " " + msg + "\r\n" +
                "Content-Type: text/plain\r\n" +
                "Content-Length: " + body.getBytes(StandardCharsets.UTF_8).length + "\r\n" +
                "Connection: close\r\n\r\n" + body;
        out.write(h.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    static void writeFrame(OutputStream out, long ptsUs, byte[] payload) throws IOException {
        ByteBuffer h = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN);
        h.putLong(ptsUs);
        h.putInt(payload.length);
        out.write(h.array());
        out.write(payload);
    }
}
