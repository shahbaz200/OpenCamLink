package com.opencamlink;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.util.Log;

final class NsdAdvertiser {
    private static final String TAG = "OpenCamLink.NSD";
    private final NsdManager manager;
    private NsdManager.RegistrationListener listener;

    NsdAdvertiser(Context context) {
        manager = (NsdManager) context.getSystemService(Context.NSD_SERVICE);
    }

    void start(int port) {
        stop();
        NsdServiceInfo info = new NsdServiceInfo();
        info.setServiceName("OpenCamLink-" + Build.MODEL);
        // Internal interoperability identifier used by the public OBS receiver.
        info.setServiceType("_droidcamobs._tcp.");
        info.setPort(port);
        try { info.setAttribute("model", Build.MODEL); } catch (Exception ignored) {}
        try { info.setAttribute("app", "OpenCamLink"); } catch (Exception ignored) {}
        listener = new NsdManager.RegistrationListener() {
            @Override public void onRegistrationFailed(NsdServiceInfo serviceInfo, int errorCode) { Log.w(TAG, "registration failed " + errorCode); }
            @Override public void onUnregistrationFailed(NsdServiceInfo serviceInfo, int errorCode) { }
            @Override public void onServiceRegistered(NsdServiceInfo serviceInfo) { Log.i(TAG, "registered " + serviceInfo.getServiceName()); }
            @Override public void onServiceUnregistered(NsdServiceInfo serviceInfo) { }
        };
        try { manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener); }
        catch (Exception e) { Log.w(TAG, "NSD registration error", e); }
    }

    void stop() {
        if (listener != null) {
            try { manager.unregisterService(listener); } catch (Exception ignored) {}
            listener = null;
        }
    }
}
