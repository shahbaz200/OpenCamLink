package com.opencamlink;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.ColorSpaceTransform;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Range;
import android.util.Rational;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

final class CameraController {
    private static final String TAG = "OpenCamLink.Camera";
    private final Context context;
    private final VideoBroadcaster broadcaster;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private HandlerThread codecThread;
    private Handler codecHandler;

    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder request;
    private MediaCodec codec;
    private Surface codecSurface;
    private volatile Surface previewSurface;

    private String selection;
    private String openCameraId;
    private String physicalCameraId;
    private CameraCharacteristics logicalCharacteristics;
    private CameraCharacteristics selectedCharacteristics;

    private int width = 1920;
    private int height = 1080;
    private int fps = 60;
    private int bitrate = 20_000_000;

    private float zoom = 1f;
    private boolean manualExposure = false;
    private int iso = 200;
    private long exposureNs = 8_333_333L;
    private int aeComp = 0;
    private int awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO;
    private boolean manualWb = false;
    private int wbKelvin = 5000;
    private boolean manualFocus = false;
    private float focusDistance = 0f;
    private int antiBanding = CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO;
    private boolean ois = true;
    private boolean eis = false;
    private boolean torch = false;
    private Range<Integer> fpsRange;
    private RggbChannelVector lastAutoWbGains;
    private ColorSpaceTransform lastAutoWbTransform;

    CameraController(Context context, VideoBroadcaster broadcaster) {
        this.context = context;
        this.broadcaster = broadcaster;
    }

    void configure(String selection, int width, int height, int fps, int bitrate) {
        this.selection = selection;
        this.width = width;
        this.height = height;
        this.fps = fps;
        this.bitrate = bitrate;
    }

    void setPreviewSurface(Surface surface) {
        previewSurface = surface;
        Handler h = cameraHandler;
        if (h != null) h.post(() -> { if (camera != null) createSession(); });
    }

    @SuppressLint("MissingPermission")
    void start() throws Exception {
        cameraThread = new HandlerThread("OpenCamLink-Camera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        codecThread = new HandlerThread("OpenCamLink-Codec");
        codecThread.start();
        codecHandler = new Handler(codecThread.getLooper());

        CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        CameraCatalog.LensOption option = CameraCatalog.resolve(cm, selection);
        selection = option.selection;
        openCameraId = option.openId;
        physicalCameraId = option.physicalId;
        logicalCharacteristics = cm.getCameraCharacteristics(openCameraId);
        try { selectedCharacteristics = CameraCatalog.selectedCharacteristics(cm, option); }
        catch (Exception e) { selectedCharacteristics = logicalCharacteristics; }
        // Prefer an exact/containing range. Physical-camera metadata on some Samsung devices
        // omits 60 fps even though the logical camera can drive that physical output at 60.
        fpsRange = chooseExactFpsRange(selectedCharacteristics, fps);
        if (fpsRange == null) fpsRange = chooseExactFpsRange(logicalCharacteristics, fps);
        if (fpsRange == null) fpsRange = chooseNearestFpsRange(logicalCharacteristics, fps);
        if (fpsRange == null) fpsRange = chooseNearestFpsRange(selectedCharacteristics, fps);

        setupCodec();
        cm.openCamera(openCameraId, new CameraDevice.StateCallback() {
            @Override public void onOpened(CameraDevice c) { camera = c; createSession(); }
            @Override public void onDisconnected(CameraDevice c) { c.close(); camera = null; }
            @Override public void onError(CameraDevice c, int error) { c.close(); camera = null; }
        }, cameraHandler);
    }

    private Range<Integer> chooseExactFpsRange(CameraCharacteristics cc, int target) {
        if (cc == null) return null;
        try {
            Range<Integer>[] ranges = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            Range<Integer> best = null;
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    if (r.getLower() == target && r.getUpper() == target) return r;
                    if (r.getUpper() == target && (best == null || r.getLower() > best.getLower())) best = r;
                }
                if (best != null) return best;
                for (Range<Integer> r : ranges) {
                    if (r.contains(target) && (best == null || r.getLower() > best.getLower())) best = r;
                }
            }
            return best;
        } catch (Exception ignored) { return null; }
    }

    private Range<Integer> chooseNearestFpsRange(CameraCharacteristics cc, int target) {
        if (cc == null) return null;
        try {
            Range<Integer>[] ranges = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            Range<Integer> best = null;
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    if (best == null || Math.abs(r.getUpper() - target) < Math.abs(best.getUpper() - target)) best = r;
                }
            }
            return best;
        } catch (Exception ignored) { return null; }
    }

    private Range<Integer> chooseHighSpeedRange() {
        if (fps <= 60 || physicalCameraId != null || logicalCharacteristics == null) return null;
        try {
            android.hardware.camera2.params.StreamConfigurationMap map = logicalCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) return null;
            Range<Integer>[] ranges = map.getHighSpeedVideoFpsRangesFor(new android.util.Size(width, height));
            if (ranges != null) {
                Range<Integer> best = null;
                for (Range<Integer> r : ranges) {
                    if (r.getUpper() == fps && r.getLower() == fps) return r;
                    if (r.getUpper() == fps && (best == null || r.getLower() > best.getLower())) best = r;
                }
                return best;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void setupCodec() throws Exception {
        MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        try { fmt.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR); } catch (Exception ignored) { }
        try { fmt.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh); } catch (Exception ignored) { }
        // Let MediaCodec choose the correct H.264 level so 1440p/4K modes are not artificially capped.

        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        codec.setCallback(new MediaCodec.Callback() {
            @Override public void onInputBufferAvailable(MediaCodec codec, int index) { }
            @Override public void onOutputBufferAvailable(MediaCodec mc, int index, MediaCodec.BufferInfo info) {
                try {
                    ByteBuffer bb = mc.getOutputBuffer(index);
                    if (bb == null) return;
                    bb.position(info.offset);
                    bb.limit(info.offset + info.size);
                    byte[] data = new byte[info.size];
                    bb.get(data);
                    boolean config = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                    boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                    if (data.length > 0) broadcaster.publish(new Frame(info.presentationTimeUs, data, config, key));
                } finally {
                    mc.releaseOutputBuffer(index, false);
                }
            }
            @Override public void onError(MediaCodec codec, MediaCodec.CodecException e) { Log.e(TAG, "encoder error", e); }
            @Override public void onOutputFormatChanged(MediaCodec mc, MediaFormat format) {
                try {
                    ByteBuffer sps = format.getByteBuffer("csd-0");
                    ByteBuffer pps = format.getByteBuffer("csd-1");
                    if (sps != null) {
                        byte[] a = new byte[sps.remaining()]; sps.duplicate().get(a);
                        byte[] b = new byte[pps == null ? 0 : pps.remaining()];
                        if (pps != null) pps.duplicate().get(b);
                        byte[] both = new byte[a.length + b.length];
                        System.arraycopy(a, 0, both, 0, a.length);
                        System.arraycopy(b, 0, both, a.length, b.length);
                        broadcaster.publish(new Frame(0, both, true, true));
                    }
                } catch (Exception ignored) { }
            }
        }, codecHandler);
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codecSurface = codec.createInputSurface();
        broadcaster.setCodec(codec);
        codec.start();
    }

    private final CameraCaptureSession.CaptureCallback captureCallback = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest req, TotalCaptureResult result) {
            if (!manualWb) {
                try {
                    RggbChannelVector g = result.get(CaptureResult.COLOR_CORRECTION_GAINS);
                    ColorSpaceTransform t = result.get(CaptureResult.COLOR_CORRECTION_TRANSFORM);
                    if (g != null) lastAutoWbGains = g;
                    if (t != null) lastAutoWbTransform = t;
                } catch (Exception ignored) { }
            }
        }
    };

    private void createSession() {
        if (camera == null || codecSurface == null) return;
        try {
            if (session != null) { try { session.close(); } catch (Exception ignored) { } session = null; }

            request = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            List<Surface> surfaces = new ArrayList<>();
            surfaces.add(codecSurface);
            request.addTarget(codecSurface);

            Range<Integer> hsRange = chooseHighSpeedRange();
            boolean highSpeed = hsRange != null;
            if (highSpeed) fpsRange = hsRange;

            // High-speed Camera2 sessions are intentionally video-only. This avoids OEM failures
            // from combining a small phone preview surface with a constrained 120/240 fps stream.
            Surface p = previewSurface;
            if (!highSpeed && p != null && p.isValid()) { surfaces.add(p); request.addTarget(p); }
            applyControls(request);

            CameraCaptureSession.StateCallback cb = new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    try {
                        if (highSpeed && s instanceof CameraConstrainedHighSpeedCaptureSession) {
                            CameraConstrainedHighSpeedCaptureSession hs = (CameraConstrainedHighSpeedCaptureSession)s;
                            List<CaptureRequest> burst = hs.createHighSpeedRequestList(request.build());
                            hs.setRepeatingBurst(burst, captureCallback, cameraHandler);
                        } else {
                            s.setRepeatingRequest(request.build(), captureCallback, cameraHandler);
                        }
                    } catch (CameraAccessException | IllegalArgumentException e) { Log.e(TAG, "repeat request", e); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { Log.e(TAG, "capture session configuration failed"); }
            };

            if (highSpeed) {
                camera.createConstrainedHighSpeedCaptureSession(surfaces, cb, cameraHandler);
            } else if (Build.VERSION.SDK_INT >= 28 && physicalCameraId != null && !physicalCameraId.isEmpty()) {
                List<OutputConfiguration> configs = new ArrayList<>();
                for (Surface surface : surfaces) {
                    OutputConfiguration oc = new OutputConfiguration(surface);
                    oc.setPhysicalCameraId(physicalCameraId);
                    configs.add(oc);
                }
                Executor ex = command -> cameraHandler.post(command);
                SessionConfiguration sc = new SessionConfiguration(SessionConfiguration.SESSION_REGULAR, configs, ex, cb);
                camera.createCaptureSession(sc);
            } else {
                camera.createCaptureSession(surfaces, cb, cameraHandler);
            }
        } catch (Exception e) {
            Log.e(TAG, "create session", e);
        }
    }

    private void applyControls(CaptureRequest.Builder b) {
        try { b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO); } catch (Exception ignored) { }
        try { if (fpsRange != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE, antiBanding); } catch (Exception ignored) { }

        if (manualWb) {
            try { b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF); } catch (Exception ignored) { }
            try {
                b.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX);
                ColorSpaceTransform transform = lastAutoWbTransform;
                if (transform == null && selectedCharacteristics != null) {
                    try { transform = selectedCharacteristics.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM1); } catch (Exception ignored) { }
                }
                if (transform == null) transform = identityTransform();
                b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, transform);
                b.set(CaptureRequest.COLOR_CORRECTION_GAINS, kelvinToGains(wbKelvin, lastAutoWbGains));
            } catch (Exception ignored) { }
        } else {
            try { b.set(CaptureRequest.CONTROL_AWB_MODE, awbMode); } catch (Exception ignored) { }
        }

        if (manualExposure) {
            try { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.SENSOR_SENSITIVITY, clampIso(iso)); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, clampExposure(exposureNs)); } catch (Exception ignored) { }
        } else {
            try { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, clampAeComp(aeComp)); } catch (Exception ignored) { }
        }

        if (manualFocus) {
            try { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.LENS_FOCUS_DISTANCE, clampFocus(focusDistance)); } catch (Exception ignored) { }
        } else {
            try { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO); } catch (Exception ignored) { }
        }

        try { b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                ois ? CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON : CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                eis ? CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON : CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF); } catch (Exception ignored) { }

        boolean flashAvailable = false;
        try { Boolean fa = logicalCharacteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE); flashAvailable = Boolean.TRUE.equals(fa); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.FLASH_MODE, torch && flashAvailable ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF); }
        catch (Exception ignored) { }

        applyZoom(b);
    }

    private void applyZoom(CaptureRequest.Builder b) {
        // Auto/logical mode: CONTROL_ZOOM_RATIO is the correct way to let the OEM switch
        // between ultra-wide/wide/tele lenses as zoom crosses their thresholds.
        if (physicalCameraId == null) {
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    Range<Float> zr = logicalCharacteristics.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                    if (zr != null) {
                        float z = Math.max(zr.getLower(), Math.min(zoom, zr.getUpper()));
                        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, z);
                        return;
                    }
                }
            } catch (Exception ignored) { }
        }

        // Manual physical-lens mode: crop in THAT lens' active array, not the logical
        // camera's array. Using the logical array was the v0.6 cause of stuck/cropped zoom.
        try {
            CameraCharacteristics cc = physicalCameraId != null ? selectedCharacteristics : logicalCharacteristics;
            Rect active = cc == null ? null : cc.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float maxZoom = cc == null ? null : cc.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (active != null && maxZoom != null) {
                float z = Math.max(1f, Math.min(zoom, maxZoom));
                int cropW = Math.max(2, (int)(active.width() / z));
                int cropH = Math.max(2, (int)(active.height() / z));
                int left = active.centerX() - cropW / 2;
                int top = active.centerY() - cropH / 2;
                Rect crop = new Rect(left, top, left + cropW, top + cropH);
                if (Build.VERSION.SDK_INT >= 28 && physicalCameraId != null) {
                    try { b.setPhysicalCameraKey(CaptureRequest.SCALER_CROP_REGION, crop, physicalCameraId); }
                    catch (Exception ignored) { b.set(CaptureRequest.SCALER_CROP_REGION, crop); }
                } else {
                    b.set(CaptureRequest.SCALER_CROP_REGION, crop);
                }
            }
        } catch (Exception ignored) { }
    }

    void updateControls(boolean manualExposure, int iso, long exposureNs, int aeComp,
                        int awbMode, boolean manualWb, int wbKelvin,
                        boolean manualFocus, float focusDistance, float zoom,
                        int antiBanding, boolean ois, boolean eis, boolean torch,
                        int newBitrate) {
        Handler h = cameraHandler;
        if (h == null) return;
        h.post(() -> {
            CameraController.this.manualExposure = manualExposure;
            CameraController.this.iso = iso;
            CameraController.this.exposureNs = exposureNs;
            CameraController.this.aeComp = aeComp;
            CameraController.this.awbMode = awbMode;
            CameraController.this.manualWb = manualWb;
            CameraController.this.wbKelvin = Math.max(1800, Math.min(wbKelvin, 12000));
            CameraController.this.manualFocus = manualFocus;
            CameraController.this.focusDistance = focusDistance;
            CameraController.this.zoom = zoom;
            CameraController.this.antiBanding = antiBanding;
            CameraController.this.ois = ois;
            CameraController.this.eis = eis;
            CameraController.this.torch = torch;

            int safeBitrate = Math.max(1_000_000, Math.min(newBitrate, 80_000_000));
            if (safeBitrate != bitrate && codec != null) {
                try {
                    Bundle params = new Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, safeBitrate);
                    codec.setParameters(params);
                    bitrate = safeBitrate;
                    Log.i(TAG, "live bitrate changed to " + safeBitrate);
                } catch (Exception e) { Log.w(TAG, "live bitrate update failed", e); }
            }

            if (request != null && session != null) {
                applyControls(request);
                try { session.setRepeatingRequest(request.build(), null, cameraHandler); }
                catch (Exception e) { Log.w(TAG, "control update failed", e); }
            }
        });
    }

    private CameraCharacteristics rangeCharacteristics() {
        return selectedCharacteristics != null ? selectedCharacteristics : logicalCharacteristics;
    }

    private int clampIso(int value) {
        try {
            Range<Integer> r = rangeCharacteristics().get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            return r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
        } catch (Exception ignored) { return value; }
    }

    private long clampExposure(long value) {
        try {
            Range<Long> r = rangeCharacteristics().get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            long v = r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
            long frameLimit = (long) (1_000_000_000L / Math.max(1, fps));
            return Math.min(v, frameLimit);
        } catch (Exception ignored) { return value; }
    }

    private int clampAeComp(int value) {
        try {
            Range<Integer> r = rangeCharacteristics().get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            return r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
        } catch (Exception ignored) { return value; }
    }

    private float clampFocus(float value) {
        try {
            Float max = rangeCharacteristics().get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
            if (max == null || max <= 0f) return 0f;
            return Math.max(0f, Math.min(value, max));
        } catch (Exception ignored) { return value; }
    }

    private static ColorSpaceTransform identityTransform() {
        Rational z = new Rational(0, 1), o = new Rational(1, 1);
        return new ColorSpaceTransform(new Rational[]{o,z,z, z,o,z, z,z,o});
    }

    private static RggbChannelVector kelvinToGains(int kelvin, RggbChannelVector autoBase) {
        // Apply a temperature shift on top of the last valid vendor AWB gains. Keeping the
        // vendor's sensor-specific color transform/gains avoids the green/blue hue seen in v0.6.
        float[] target = temperatureGainPair(kelvin);
        float[] neutral = temperatureGainPair(5000);
        float baseR = autoBase == null ? 1f : autoBase.getRed();
        float baseGe = autoBase == null ? 1f : autoBase.getGreenEven();
        float baseGo = autoBase == null ? 1f : autoBase.getGreenOdd();
        float baseB = autoBase == null ? 1f : autoBase.getBlue();
        float r = clampGain(baseR * target[0] / Math.max(0.05f, neutral[0]));
        float b = clampGain(baseB * target[1] / Math.max(0.05f, neutral[1]));
        return new RggbChannelVector(r, clampGain(baseGe), clampGain(baseGo), b);
    }

    private static float[] temperatureGainPair(int kelvin) {
        double t = Math.max(1800, Math.min(12000, kelvin)) / 100.0;
        double r, g, b;
        if (t <= 66) {
            r = 255;
            g = 99.4708025861 * Math.log(t) - 161.1195681661;
            b = t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307;
        } else {
            r = 329.698727446 * Math.pow(t - 60, -0.1332047592);
            g = 288.1221695283 * Math.pow(t - 60, -0.0755148492);
            b = 255;
        }
        r = clamp255(r); g = clamp255(g); b = clamp255(b);
        double gn = Math.max(1.0, g);
        return new float[]{
                (float)Math.max(0.2, Math.min(8.0, gn / Math.max(1.0, r))),
                (float)Math.max(0.2, Math.min(8.0, gn / Math.max(1.0, b)))
        };
    }

    private static float clampGain(float v) { return Math.max(0.2f, Math.min(8f, v)); }

    private static double clamp255(double v) { return Math.max(0, Math.min(255, v)); }

    void stop() {
        try { if (session != null) session.close(); } catch (Exception ignored) { }
        session = null;
        try { if (camera != null) camera.close(); } catch (Exception ignored) { }
        camera = null;
        try { if (codec != null) codec.stop(); } catch (Exception ignored) { }
        try { if (codec != null) codec.release(); } catch (Exception ignored) { }
        codec = null;
        codecSurface = null;
        broadcaster.setCodec(null);
        if (cameraThread != null) { cameraThread.quitSafely(); cameraThread = null; }
        if (codecThread != null) { codecThread.quitSafely(); codecThread = null; }
        cameraHandler = null;
        codecHandler = null;
    }
}
