package com.opencamlink;

import android.media.MediaCodec;
import android.os.Bundle;

import java.util.concurrent.CopyOnWriteArrayList;

final class VideoBroadcaster {
    private final CopyOnWriteArrayList<ClientWriter> clients = new CopyOnWriteArrayList<>();
    private volatile byte[] codecConfig;
    private volatile MediaCodec codec;

    void setCodec(MediaCodec codec) { this.codec = codec; }

    void add(ClientWriter c) {
        clients.add(c);
        byte[] config = codecConfig;
        if (config != null) c.enqueue(new Frame(0, config, true, true));
        MediaCodec mc = codec;
        if (mc != null) {
            try {
                Bundle params = new Bundle();
                params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                mc.setParameters(params);
            } catch (Exception ignored) {}
        }
    }

    void remove(ClientWriter c) { clients.remove(c); }

    void publish(Frame f) {
        if (f.config) codecConfig = f.data.clone();
        for (ClientWriter c : clients) c.enqueue(f);
    }

    void closeAll() {
        for (ClientWriter c : clients) c.close();
        clients.clear();
    }
}
