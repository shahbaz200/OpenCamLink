# OpenCam Link v0.6

Independent Android Camera2 H.264 webcam sender designed to interoperate with the public DroidCam OBS receiver protocol.

## v0.6 highlights

- Wi-Fi and USB/ADB video compatibility on port 4747
- OBS Studio browser dock at `/control`
- Adjustable 1–80 Mbps live H.264 bitrate
- Lens/camera selection including logical Auto mode and Camera2-exposed physical lenses
- Friendly rear-lens labels (0.6x / 1x / 3x / 10x where Camera2 metadata identifies them)
- All normal Camera2/MediaRecorder resolutions reported by the selected lens
- All normal Camera2 target FPS endpoints reported by the selected lens
- Manual exposure with shutter-speed fractions
- Manual white balance from 1800–12000 K plus presets
- Live ISO, focus, zoom, OIS/EIS, anti-flicker and torch
- Phone battery status in the OBS control dock, with show/hide option
- Portrait phone UI with auto-fit/rotated local preview to avoid stretching
- No watermark code

Physical-lens availability is determined by Android Camera2. Some phone vendors may hide specific physical cameras from third-party apps.

## OBS dock

Wi-Fi: `http://PHONE_IP:4747/control`

USB/ADB: `http://127.0.0.1:4747/control` while the USB video source/tunnel is active.
