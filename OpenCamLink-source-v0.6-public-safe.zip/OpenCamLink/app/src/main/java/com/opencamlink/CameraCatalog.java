package com.opencamlink;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/** Camera/lens discovery helpers, including logical multi-camera physical lenses. */
final class CameraCatalog {
    static final class LensOption {
        final String selection;
        final String label;
        final String openId;
        final String physicalId;
        final int facing;

        LensOption(String selection, String label, String openId, String physicalId, int facing) {
            this.selection = selection;
            this.label = label;
            this.openId = openId;
            this.physicalId = physicalId;
            this.facing = facing;
        }
    }

    private CameraCatalog() { }

    static List<LensOption> list(CameraManager cm) {
        List<LensOption> out = new ArrayList<>();
        try {
            String[] publicIds = cm.getCameraIdList();
            Set<String> referencedPhysical = new HashSet<>();
            if (Build.VERSION.SDK_INT >= 28) {
                for (String id : publicIds) {
                    try { referencedPhysical.addAll(cm.getCameraCharacteristics(id).getPhysicalCameraIds()); }
                    catch (Exception ignored) { }
                }
            }

            for (String id : publicIds) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                int facing = facing(c);
                Set<String> physical = Build.VERSION.SDK_INT >= 28 ? c.getPhysicalCameraIds() : Collections.emptySet();
                boolean logical = isLogical(c) && !physical.isEmpty();

                if (logical) {
                    String face = faceName(facing);
                    out.add(new LensOption("auto:" + id,
                            face + " Auto — automatic lens switching with zoom",
                            id, null, facing));

                    List<PhysicalInfo> infos = new ArrayList<>();
                    for (String pid : physical) {
                        try {
                            CameraCharacteristics pc = cm.getCameraCharacteristics(pid);
                            infos.add(new PhysicalInfo(pid, pc, equivalentFocalMm(pc)));
                        } catch (Exception e) {
                            infos.add(new PhysicalInfo(pid, null, Float.NaN));
                        }
                    }
                    float primaryEq = choosePrimaryEquivalent(infos);
                    infos.sort(Comparator.comparingDouble(a -> Float.isNaN(a.eqMm) ? 99999 : a.eqMm));
                    for (PhysicalInfo info : infos) {
                        String label = physicalLabel(facing, info, primaryEq);
                        out.add(new LensOption("phys:" + id + ":" + info.id, label, id, info.id, facing));
                    }
                } else if (!referencedPhysical.contains(id)) {
                    out.add(new LensOption("cam:" + id, directLabel(id, c), id, null, facing));
                }
            }

            // Fallback for OEMs which expose physical cameras as normal IDs too.
            if (out.isEmpty()) {
                for (String id : publicIds) {
                    CameraCharacteristics c = cm.getCameraCharacteristics(id);
                    out.add(new LensOption("cam:" + id, directLabel(id, c), id, null, facing(c)));
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    static String defaultSelection(CameraManager cm) {
        List<LensOption> options = list(cm);
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_FRONT && o.selection.startsWith("auto:")) return o.selection;
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_FRONT) return o.selection;
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_BACK && o.selection.startsWith("auto:")) return o.selection;
        return options.isEmpty() ? "cam:0" : options.get(0).selection;
    }

    static LensOption resolve(CameraManager cm, String selection) {
        List<LensOption> options = list(cm);
        if (selection != null) {
            for (LensOption o : options) if (selection.equals(o.selection)) return o;
            // v0.5 migration: raw camera ID.
            for (LensOption o : options) if (selection.equals(o.openId) && o.physicalId == null) return o;
        }
        String def = defaultSelection(cm);
        for (LensOption o : options) if (def.equals(o.selection)) return o;
        return options.isEmpty() ? new LensOption("cam:0", "Camera 0", "0", null, CameraCharacteristics.LENS_FACING_EXTERNAL) : options.get(0);
    }

    static CameraCharacteristics selectedCharacteristics(CameraManager cm, LensOption option) throws Exception {
        if (option.physicalId != null) {
            try { return cm.getCameraCharacteristics(option.physicalId); } catch (Exception ignored) { }
        }
        return cm.getCameraCharacteristics(option.openId);
    }

    static List<Size> resolutions(CameraManager cm, LensOption option) {
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        List<Size> out = new ArrayList<>();
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size[] sizes = map == null ? null : map.getOutputSizes(MediaRecorder.class);
            if (sizes == null && map != null) sizes = map.getOutputSizes(android.graphics.SurfaceTexture.class);
            if (sizes != null) {
                for (Size s : sizes) {
                    if (s.getWidth() < 320 || s.getHeight() < 240) continue;
                    String k = s.getWidth() + "x" + s.getHeight();
                    if (seen.add(k)) out.add(s);
                }
            }
        } catch (Exception ignored) { }
        out.sort((a, b) -> Long.compare((long)b.getWidth() * b.getHeight(), (long)a.getWidth() * a.getHeight()));
        if (out.isEmpty()) out.add(new Size(1920, 1080));
        return out;
    }

    static List<Integer> fpsOptions(CameraManager cm, LensOption option) {
        TreeSet<Integer> values = new TreeSet<>();
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            Range<Integer>[] ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    int upper = r.getUpper();
                    if (upper >= 10 && upper <= 240) values.add(upper);
                }
            }
        } catch (Exception ignored) { }
        if (values.isEmpty()) { values.add(30); values.add(60); }
        return new ArrayList<>(values);
    }

    static String resolutionLabel(Size s) {
        int w = s.getWidth(), h = s.getHeight();
        String name = "";
        if (w == 3840 && h == 2160) name = "4K UHD · ";
        else if (w == 2560 && h == 1440) name = "1440p · ";
        else if (w == 1920 && h == 1080) name = "1080p · ";
        else if (w == 1280 && h == 720) name = "720p · ";
        return name + w + "×" + h;
    }

    private static boolean isLogical(CameraCharacteristics c) {
        int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps == null) return false;
        for (int x : caps) if (x == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) return true;
        return false;
    }

    private static int facing(CameraCharacteristics c) {
        Integer f = c.get(CameraCharacteristics.LENS_FACING);
        return f == null ? CameraCharacteristics.LENS_FACING_EXTERNAL : f;
    }

    private static String faceName(int facing) {
        if (facing == CameraCharacteristics.LENS_FACING_BACK) return "Rear";
        if (facing == CameraCharacteristics.LENS_FACING_FRONT) return "Front";
        return "External";
    }

    private static String directLabel(String id, CameraCharacteristics c) {
        String face = faceName(facing(c));
        float eq = equivalentFocalMm(c);
        String eqText = Float.isNaN(eq) ? "" : String.format(Locale.US, " · ≈%.0f mm eq", eq);
        return face + " camera · ID " + id + eqText;
    }

    private static final class PhysicalInfo {
        final String id;
        final CameraCharacteristics c;
        final float eqMm;
        PhysicalInfo(String id, CameraCharacteristics c, float eqMm) { this.id = id; this.c = c; this.eqMm = eqMm; }
    }

    private static float choosePrimaryEquivalent(List<PhysicalInfo> infos) {
        float best = Float.NaN;
        float bestDistance = Float.MAX_VALUE;
        for (PhysicalInfo i : infos) {
            if (Float.isNaN(i.eqMm)) continue;
            float d = Math.abs(i.eqMm - 24f);
            if (d < bestDistance) { bestDistance = d; best = i.eqMm; }
        }
        if (!Float.isNaN(best)) return best;
        return 24f;
    }

    private static String physicalLabel(int facing, PhysicalInfo info, float primaryEq) {
        String face = faceName(facing);
        if (Float.isNaN(info.eqMm)) return face + " lens · physical ID " + info.id;
        if (facing != CameraCharacteristics.LENS_FACING_BACK) {
            return String.format(Locale.US, "%s lens · ≈%.0f mm eq · physical ID %s", face, info.eqMm, info.id);
        }
        float ratio = Math.max(0.1f, info.eqMm / Math.max(1f, primaryEq));
        float nice = nearestZoom(ratio);
        String kind = nice < 0.8f ? "ultrawide" : nice < 1.5f ? "wide" : "telephoto";
        return String.format(Locale.US, "Rear %s× %s · ≈%.0f mm eq · physical ID %s", zoomText(nice), kind, info.eqMm, info.id);
    }

    private static float nearestZoom(float value) {
        float[] common = {0.5f, 0.6f, 1f, 2f, 3f, 5f, 10f};
        float best = common[0], bestD = Float.MAX_VALUE;
        for (float x : common) {
            float d = Math.abs((float)Math.log(value / x));
            if (d < bestD) { bestD = d; best = x; }
        }
        return best;
    }

    private static String zoomText(float v) {
        if (Math.abs(v - Math.round(v)) < 0.01f) return Integer.toString(Math.round(v));
        return String.format(Locale.US, "%.1f", v);
    }

    private static float equivalentFocalMm(CameraCharacteristics c) {
        try {
            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (focal == null || focal.length == 0 || sensor == null) return Float.NaN;
            double sensorDiag = Math.hypot(sensor.getWidth(), sensor.getHeight());
            if (sensorDiag <= 0) return Float.NaN;
            return (float)(focal[0] * 43.2666153 / sensorDiag);
        } catch (Exception ignored) { return Float.NaN; }
    }
}
