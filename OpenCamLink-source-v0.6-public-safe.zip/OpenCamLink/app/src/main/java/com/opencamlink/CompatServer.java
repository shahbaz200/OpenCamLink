package com.opencamlink;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * TCP compatibility server for the public DroidCam OBS receiver protocol.
 * It also hosts the OpenCam OBS control dock and JSON control API on the same port.
 */
final class CompatServer {
    private static final String TAG = "OpenCamLink.Server";
    private static final int MAX_REQUEST = 4096;
    private final int port;
    private final VideoBroadcaster broadcaster;
    private final StreamingService owner;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private ServerSocket server;

    CompatServer(int port, VideoBroadcaster broadcaster, StreamingService owner) {
        this.port = port;
        this.broadcaster = broadcaster;
        this.owner = owner;
    }

    void start() throws Exception {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(port));
        running = true;
        pool.execute(() -> {
            while (running) {
                try {
                    Socket s = server.accept();
                    s.setTcpNoDelay(true);
                    s.setKeepAlive(true);
                    s.setSoTimeout(1200);
                    pool.execute(() -> handle(s));
                } catch (Exception e) {
                    if (running) Log.w(TAG, "accept failed", e);
                }
            }
        });
    }

    private static String readInitialRequest(Socket s) throws Exception {
        InputStream in = s.getInputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream(512);
        byte[] tmp = new byte[512];
        while (b.size() < MAX_REQUEST) {
            int n;
            try {
                n = in.read(tmp, 0, Math.min(tmp.length, MAX_REQUEST - b.size()));
            } catch (SocketTimeoutException timeout) {
                break;
            }
            if (n < 0) break;
            if (n == 0) continue;
            b.write(tmp, 0, n);
            String current = b.toString(StandardCharsets.US_ASCII.name());

            // Normal browser/API request.
            if (current.contains("\r\n\r\n")) break;

            // DroidCam OBS VIDEO_REQ has no CRLF. Its known request ends with /nonce/<n>/.
            if (current.startsWith("GET /v5/video/") && current.matches("(?s).*?/nonce/\\d+/$")) break;

            // Audio request is also headerless in the public receiver.
            if (current.startsWith("GET /v2/audio") && current.length() >= "GET /v2/audio".length()) break;
        }
        return b.toString(StandardCharsets.US_ASCII.name()).trim();
    }

    private void handle(Socket s) {
        try {
            String request = readInitialRequest(s);
            if (request.isEmpty()) { s.close(); return; }
            String requestLine = request;
            int nl = request.indexOf('\n');
            if (nl >= 0) requestLine = request.substring(0, nl).trim();
            Log.i(TAG, "request: " + requestLine);

            String target = "/";
            if (requestLine.startsWith("GET ") || requestLine.startsWith("PUT ") || requestLine.startsWith("POST ")) {
                int firstSpace = requestLine.indexOf(' ');
                int nextSpace = requestLine.indexOf(' ', firstSpace + 1);
                target = nextSpace < 0 ? requestLine.substring(firstSpace + 1) : requestLine.substring(firstSpace + 1, nextSpace);
            }
            String path = target;
            int q = target.indexOf('?');
            if (q >= 0) path = target.substring(0, q);

            if (path.startsWith("/v5/video/avc/")) {
                // RAW STREAM: no HTTP response header. OBS expects frame bytes immediately.
                s.setSoTimeout(0);
                ClientWriter client = new ClientWriter(s);
                broadcaster.add(client);
                try { client.run(); } finally { broadcaster.remove(client); }
                return;
            }

            if (path.startsWith("/v5/video/hevc/") || path.startsWith("/v5/video/mjpg/")) {
                s.close();
                return;
            }

            if (path.startsWith("/v2/audio")) {
                s.close();
                return;
            }

            if (path.equals("/control") || path.equals("/control/")) {
                byte[] body = readAsset("control.html");
                writeHttp(s, 200, "OK", "text/html; charset=utf-8", body);
                return;
            }

            if (path.equals("/api/state")) {
                writeJson(s, owner.controlStateJson());
                return;
            }

            if (path.equals("/api/set")) {
                owner.applyControlValues(parseQuery(target));
                writeJson(s, owner.controlStateJson());
                return;
            }

            if (path.equals("/api/restart")) {
                owner.applyControlValues(parseQuery(target));
                writeJson(s, owner.controlStateJson());
                owner.restartFromControlAsync();
                return;
            }

            if (path.equals("/") || path.equals("/status")) {
                String body = "OpenCam Link v0.6\nH.264 server active on port " + port + "\nOBS control dock: /control\n";
                writeHttp(s, 200, "OK", "text/plain; charset=utf-8", body.getBytes(StandardCharsets.UTF_8));
                return;
            }

            writeHttp(s, 404, "Not Found", "text/plain; charset=utf-8", "Not Found\n".getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) { }
            Log.i(TAG, "connection ended: " + e.getMessage());
        }
    }

    private byte[] readAsset(String name) throws Exception {
        try (InputStream in = owner.getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static Map<String, String> parseQuery(String target) {
        Map<String, String> out = new LinkedHashMap<>();
        int q = target.indexOf('?');
        if (q < 0 || q + 1 >= target.length()) return out;
        String query = target.substring(q + 1);
        for (String pair : query.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = eq < 0 ? pair : pair.substring(0, eq);
            String v = eq < 0 ? "" : pair.substring(eq + 1);
            try {
                k = URLDecoder.decode(k, "UTF-8");
                v = URLDecoder.decode(v, "UTF-8");
            } catch (Exception ignored) { }
            out.put(k, v);
        }
        return out;
    }

    private static void writeJson(Socket s, String json) throws Exception {
        writeHttp(s, 200, "OK", "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
    }

    private static void writeHttp(Socket s, int code, String reason, String type, byte[] body) throws Exception {
        OutputStream out = s.getOutputStream();
        String h = "HTTP/1.1 " + code + " " + reason + "\r\n" +
                "Content-Type: " + type + "\r\n" +
                "Content-Length: " + body.length + "\r\n" +
                "Cache-Control: no-store\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        out.write(body);
        out.flush();
        s.close();
    }

    void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        pool.shutdownNow();
        broadcaster.closeAll();
    }
}
