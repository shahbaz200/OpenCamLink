# OpenCam Link v0.3 v0.1 (source build)

OpenCam Link is an **independent Android camera streamer** designed to interoperate with the publicly available OBS receiver interface used by the DroidCam OBS plugin. It contains no code, assets, logos, names, billing logic, or entitlement logic from the proprietary Android app.

## Goal

- Android Camera2 capture
- Hardware H.264/AVC encoding with `MediaCodec`
- 1920×1080 at 30/60 FPS (hardware permitting)
- 8–32 Mbps selectable bitrate
- 1-second GOP / keyframe interval
- Wi-Fi: TCP server on port 4747 + DNS-SD advertisement
- USB: works through the OBS plugin's normal ADB TCP port forwarding when USB debugging is enabled
- Manual camera controls: ISO, shutter/exposure, exposure compensation, AWB mode, manual focus, zoom, anti-flicker, OIS/EIS
- No watermark by design

## Compatibility protocol

The receiver-side plugin is public GPL-2.0 software and advertises Wi-Fi/USB support. Public interoperability documentation also describes the current video request and stream framing. This project implements only the network-facing compatibility layer independently:

- HTTP request path beginning with `/v5/video/avc/...`
- HTTP 200 response followed by repeated frames
- frame header: 8-byte big-endian PTS + 4-byte big-endian payload length
- H.264 codec configuration packets use PTS 0

The app registers `_droidcamobs._tcp.` only as a protocol discovery identifier so the existing receiver can discover the service; the user-facing app name remains OpenCam Link.

## Build

Open this folder in Android Studio (JDK 17) and build `app`.

Command line, if Android SDK + Gradle are installed:

```bash
gradle :app:assembleDebug
```

The debug APK will be:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Signing a release APK

Generate your own signing key once:

```bash
keytool -genkeypair -v -keystore opencamlink-release.jks \
  -alias opencamlink -keyalg RSA -keysize 3072 -validity 10000
```

Then configure an Android Studio signing configuration or use `apksigner` from Android Build Tools.

## OBS test

1. Start OpenCam Link and press **START 1080P STREAM SERVER**.
2. Wi-Fi: OBS → Add Source → DroidCam OBS → enable **Use WiFi IP** → enter phone IP → AVC → 1920×1080.
3. USB: enable Android Developer Options + USB Debugging; connect phone; in the OBS source press **Refresh Device List** and choose the Android device. The plugin forwards the TCP port through ADB.
4. Start with 1080p30 / 12 Mbps to verify protocol compatibility, then switch the app to 60 FPS / 20 Mbps.

## Current v0.1 limitations

- Video only. The receiver's audio transport has not been implemented yet.
- AVC/H.264 only; HEVC and MJPEG can be added after the first protocol test.
- The server currently accepts the public `/v5/video/avc/...` stream request but does not yet implement every auxiliary control/probe endpoint that future plugin versions may query.
- 60 FPS depends on the selected camera's Camera2 output capabilities. On high-end modern phones 1080p60 is commonly supported, but the app should probe exact supported FPS/resolution combinations in a later build.
- No in-app preview in v0.1, to keep the camera pipeline simple and maximize encoder performance.

## License

The original OpenCam Link source in this folder is provided under GPL-2.0-only for straightforward compatibility with the GPL-2.0 receiver ecosystem. Third-party trademarks belong to their respective owners.

## Protocol smoke test without OBS

A small receiver is included in `tools/test_receiver.py`.

Wi-Fi:

```bash
python tools/test_receiver.py PHONE_IP capture.h264
```

USB (ADB):

```bash
adb forward tcp:4747 tcp:4747
python tools/test_receiver.py 127.0.0.1 usb_capture.h264
```

Open `capture.h264` in VLC/ffplay. This isolates phone-server/encoder problems from OBS-plugin problems.

## v0.2 build automation

This project now contains `.github/workflows/build-apk.yml`. A GitHub Actions runner can build an installable **signed release APK** without Android Studio. The output artifact is named `OpenCamLink-v0.2.apk`.

A dedicated development signing key is included under `signing/` so future v0.2+ builds can update the installed app without Android rejecting a changed signature. Treat this key as a private development key and do not use it for Play Store production distribution.


## v0.3 receiver compatibility fix

The public OBS receiver sends its video request as a headerless string and immediately expects raw 12-byte framed video packets. v0.3 handles that wire format directly and marks codec-configuration packets with PTS `UINT64_MAX` as expected by the receiver. It also shows Wi-Fi interface addresses before VPN/Tailscale interfaces to avoid accidentally using a non-LAN IP.
