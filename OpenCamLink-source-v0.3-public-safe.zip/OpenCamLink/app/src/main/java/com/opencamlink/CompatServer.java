package com.opencamlink;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * TCP compatibility server for the public DroidCam OBS receiver network protocol.
 *
 * Important protocol detail: the OBS plugin sends the VIDEO_REQ string without an
 * HTTP version or CRLF terminator and then immediately waits for the 12-byte binary
 * frame header. Therefore this path MUST NOT wait for readLine() and MUST NOT emit
 * an HTTP/1.1 200 response before the binary stream.
 */
final class CompatServer {
    private static final String TAG = "OpenCamLink.Server";
    private static final int MAX_REQUEST = 1024;
    private final int port;
    private final VideoBroadcaster broadcaster;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private ServerSocket server;

    CompatServer(int port, VideoBroadcaster broadcaster) {
        this.port = port;
        this.broadcaster = broadcaster;
    }

    void start() throws Exception {
        server = new ServerSocket(port);
        server.setReuseAddress(true);
        running = true;
        pool.execute(() -> {
            while (running) {
                try {
                    Socket s = server.accept();
                    s.setTcpNoDelay(true);
                    s.setKeepAlive(true);
                    s.setSoTimeout(1200);
                    pool.execute(() -> handle(s));
                } catch (Exception e) {
                    if (running) Log.w(TAG, "accept failed", e);
                }
            }
        });
    }

    private static String readInitialRequest(Socket s) throws Exception {
        InputStream in = s.getInputStream();
        ByteArrayOutputStream b = new ByteArrayOutputStream(256);
        byte[] tmp = new byte[256];
        while (b.size() < MAX_REQUEST) {
            int n;
            try {
                n = in.read(tmp, 0, Math.min(tmp.length, MAX_REQUEST - b.size()));
            } catch (SocketTimeoutException timeout) {
                break;
            }
            if (n < 0) break;
            if (n == 0) continue;
            b.write(tmp, 0, n);
            String current = b.toString(StandardCharsets.US_ASCII.name());

            // Normal HTTP probe: headers have ended.
            if (current.contains("\r\n\r\n")) break;

            // DroidCam OBS VIDEO_REQ has no CRLF. Its known request ends with
            // /nonce/<decimal>/ . Once that suffix is complete, parsing is done.
            if (current.startsWith("GET /v5/video/") && current.matches("(?s).*?/nonce/\\d+/$")) break;

            // Audio request is similarly headerless in the public receiver.
            if (current.startsWith("GET /v2/audio") && current.length() >= "GET /v2/audio".length()) break;
        }
        return b.toString(StandardCharsets.US_ASCII.name()).trim();
    }

    private void handle(Socket s) {
        try {
            String request = readInitialRequest(s);
            Log.i(TAG, "request: " + request);
            if (request.isEmpty()) { s.close(); return; }

            String path = "/";
            if (request.startsWith("GET ") || request.startsWith("PUT ")) {
                int firstSpace = request.indexOf(' ');
                int nextSpace = request.indexOf(' ', firstSpace + 1);
                if (nextSpace < 0) path = request.substring(firstSpace + 1);
                else path = request.substring(firstSpace + 1, nextSpace);
            }

            if (path.startsWith("/v5/video/avc/")) {
                // RAW STREAM: no HTTP status/header here. The OBS receiver expects
                // a 12-byte binary frame header as the first bytes from the server.
                s.setSoTimeout(0);
                ClientWriter client = new ClientWriter(s);
                broadcaster.add(client);
                try { client.run(); } finally { broadcaster.remove(client); }
                return;
            }

            if (path.startsWith("/v5/video/hevc/") || path.startsWith("/v5/video/mjpg/")) {
                // v0.3 only encodes AVC/H.264.
                s.close();
                return;
            }

            if (path.startsWith("/v2/audio")) {
                // Audio transport will be added separately; close cleanly so video
                // can continue when "Enable Audio" is off in OBS.
                s.close();
                return;
            }

            // Browser/manual health probes use real HTTP.
            OutputStream out = s.getOutputStream();
            if (path.equals("/") || path.startsWith("/status")) {
                String body = "OpenCam Link\nH.264 compatibility server active on port " + port + "\n";
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                String h = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes(StandardCharsets.US_ASCII));
                out.write(bytes);
                out.flush();
                s.close();
                return;
            }

            Protocol.writeHttpError(out, 404, "Not Found");
            s.close();
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) {}
            Log.i(TAG, "connection ended: " + e.getMessage());
        }
    }

    void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
        broadcaster.closeAll();
    }
}
