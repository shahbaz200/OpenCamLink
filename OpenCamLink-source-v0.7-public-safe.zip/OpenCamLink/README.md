# OpenCam Link v0.7

Independent Android Camera2 H.264 webcam sender designed to interoperate with the public DroidCam OBS receiver protocol.

## v0.7 changes

- Keeps the known-working 30 and 60 FPS choices; adds Camera2-advertised modes above 60 for supported resolutions
- Uses constrained high-speed Camera2 capture for supported >60 FPS logical-camera modes (phone preview is disabled above 60 FPS)
- Resolution list is intentionally limited to supported 720p, 1080p, 2K/1440p and 4K UHD
- Lens or resolution changes reset zoom to 1x
- Fixed manual-physical-lens zoom cropping by using the selected physical sensor active array and physical camera crop key
- Auto lens mode uses CONTROL_ZOOM_RATIO so OEM lens switching can occur naturally
- Shutter speed is a continuous logarithmic slider again, displayed as fractions such as 1/60 s
- Manual white-balance temperature uses the camera vendor's captured AWB color transform/gains as the calibration base instead of an identity transform, avoiding the green/blue hue from v0.6
- Live bitrate, ISO, AE compensation, manual focus, zoom, OIS/EIS, anti-flicker and torch remain available
- OBS browser dock remains available at /control
- Battery status remains available in the OBS dock
- Wi-Fi and USB/ADB transport remain on port 4747
- No watermark code

Physical-lens and high-speed availability depend on what Android Camera2 exposes for the phone.

## OBS dock

Wi-Fi: `http://PHONE_IP:4747/control`

USB/ADB: `http://127.0.0.1:4747/control` while the USB video source/tunnel is active.
