package com.opencamlink;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private List<CameraCatalog.LensOption> lensOptions = new ArrayList<>();
    private List<Size> resolutionOptions = new ArrayList<>();
    private List<Integer> fpsOptions = new ArrayList<>();

    private Spinner cameraSpinner, resolutionSpinner, fpsSpinner, awbSpinner, antiSpinner;
    private CheckBox manualExposure, manualFocus, ois, eis, torch, showBattery;
    private SeekBar bitrateBar, isoBar, shutterBar, aeBar, kelvinBar, focusBar, zoomBar;
    private TextView bitrateText, isoText, shutterText, aeText, kelvinText, focusText, zoomText, statusText;
    private TextureView previewView;
    private Surface previewSurface;
    private int previewBufferW = 640, previewBufferH = 360;
    private long shutterMinNs = 100_000L, shutterMaxNs = 16_000_000L;

    private StreamingService service;
    private boolean bound;
    private boolean initializing = true;
    private boolean pipelineUpdating = false;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((StreamingService.LocalBinder) binder).getService();
            bound = true; attachPreviewIfReady(); refreshStatus();
        }
        @Override public void onServiceDisconnected(ComponentName name) { bound = false; service = null; refreshStatus(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        if (!prefs.getBoolean("v07_zoom_reset_done", false)) {
            prefs.edit().putFloat("zoom", 1f).putBoolean("v07_zoom_reset_done", true).apply();
        }
        requestPermissionsIfNeeded();
        buildUi();
        initializing = false;
    }

    @Override protected void onStart() { super.onStart(); bindService(new Intent(this, StreamingService.class), connection, Context.BIND_AUTO_CREATE); }
    @Override protected void onStop() {
        if (bound) {
            try { if (service != null && previewSurface != null) service.clearPreviewSurface(previewSurface); } catch (Exception ignored) { }
            try { unbindService(connection); } catch (Exception ignored) { }
            bound = false; service = null;
        }
        super.onStop();
    }

    private void requestPermissionsIfNeeded() {
        List<String> req = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) req.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) req.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), 100);
    }

    private TextView label(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(16); v.setPadding(0, 16, 0, 6); root.addView(v); return v;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28, 28, 28, 40); sv.addView(root);

        TextView title = new TextView(this); title.setText("OpenCam Link v0.7"); title.setTextSize(28); root.addView(title);
        TextView sub = new TextView(this); sub.setText("H.264 Camera2 streamer with live phone preview and full OBS Studio control dock. No watermark."); root.addView(sub);
        statusText = label("Status: waiting for service");
        String dockIp = primaryWifiIpv4();
        label("Network addresses: " + localIpv4() + "   |   port 4747\nOBS dock: http://" + dockIp + ":4747/control\nUSB dock: http://127.0.0.1:4747/control");

        label("Live preview (auto-fit; no stretching)");
        previewView = new TextureView(this);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int previewH = Math.min((screenW * 16) / 9, dp(560));
        previewView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(dp(320), previewH)));
        previewView.setOpaque(false);
        previewView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
                configurePreviewBuffer(st); previewSurface = new Surface(st); configurePreviewTransform(width, height); attachPreviewIfReady();
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) { configurePreviewBuffer(st); configurePreviewTransform(width, height); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (service != null && previewSurface != null) service.clearPreviewSurface(previewSurface);
                if (previewSurface != null) previewSurface.release(); previewSurface = null; return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        root.addView(previewView);

        loadLenses();
        label("Lens / camera (restart to apply)");
        cameraSpinner = spinner(labelsForLenses());
        selectSavedLens();

        label("Resolution (restart to apply)");
        resolutionSpinner = spinner(Collections.singletonList("Loading…"));
        label("Frame rate (restart to apply)");
        fpsSpinner = spinner(Collections.singletonList("Loading…"));
        reloadPipelineOptions(false);

        label("Bitrate (LIVE, 1–80 Mbps)");
        bitrateText = label("");
        int savedMbpsX2 = Math.max(2, Math.min(160, Math.round(prefs.getInt("bitrate", 20_000_000) / 500_000f)));
        bitrateBar = seek(2, 160, savedMbpsX2, v -> {
            int bps = v * 500_000; prefs.edit().putInt("bitrate", bps).apply(); bitrateText.setText(String.format(Locale.US, "Bitrate: %.1f Mbps (LIVE)", bps / 1e6)); applyLive();
        });
        updateBitrateLabel();

        manualExposure = check("Manual exposure (LIVE)", prefs.getBoolean("manual_exposure", false));
        isoText = label("");
        isoBar = seek(50, 6400, prefs.getInt("iso", 200), v -> { prefs.edit().putInt("iso", v).apply(); isoText.setText("ISO: " + v + " (LIVE)"); applyLive(); });
        isoText.setText("ISO: " + prefs.getInt("iso", 200) + " (LIVE)");

        label("Shutter speed (LIVE)");
        shutterText = label("");
        shutterBar = seek(0, 1000, 500, v -> {
            long ns = shutterFromSlider(v);
            prefs.edit().putLong("exposure_ns", ns).apply();
            shutterText.setText("Shutter: " + shutterLabel(ns) + " (LIVE)");
            applyLive();
        });
        rebuildShutterRange();

        aeText = label("");
        aeBar = seek(-12, 12, prefs.getInt("ae_comp", 0), v -> { prefs.edit().putInt("ae_comp", v).apply(); aeText.setText("Exposure compensation: " + (v > 0 ? "+" : "") + v + " (LIVE)"); applyLive(); });
        aeText.setText("Exposure compensation: " + prefs.getInt("ae_comp", 0) + " (LIVE)");

        label("White balance (LIVE)");
        awbSpinner = spinner(wbLabels());
        selectSavedWb();
        kelvinText = label("");
        kelvinBar = seek(18, 120, Math.max(18, Math.min(120, prefs.getInt("wb_kelvin", 5000) / 100)), v -> {
            int k = v * 100; prefs.edit().putInt("wb_kelvin", k).apply(); kelvinText.setText("Manual WB: " + k + " K (LIVE)"); applyLive();
        });
        kelvinText.setText("Manual WB: " + prefs.getInt("wb_kelvin", 5000) + " K (LIVE)");

        manualFocus = check("Manual focus (LIVE)", prefs.getBoolean("manual_focus", false));
        focusText = label("");
        focusBar = seek(0, 2000, (int)(prefs.getFloat("focus_distance", 0f) * 100), v -> {
            float d = v / 100f; prefs.edit().putFloat("focus_distance", d).apply(); focusText.setText(String.format(Locale.US, "Focus: %.2f D (LIVE)", d)); applyLive();
        });
        focusText.setText(String.format(Locale.US, "Focus: %.2f D (LIVE)", prefs.getFloat("focus_distance", 0f)));

        zoomText = label("");
        zoomBar = seek(100, 10000, (int)(prefs.getFloat("zoom", 1f) * 100), v -> {
            float z = v / 100f; prefs.edit().putFloat("zoom", z).apply(); zoomText.setText(String.format(Locale.US, "Zoom: %.2f× (LIVE)", z)); applyLive();
        });
        zoomText.setText(String.format(Locale.US, "Zoom: %.2f× (LIVE)", prefs.getFloat("zoom", 1f)));

        label("Anti-flicker (LIVE)");
        antiSpinner = spinner(list("Auto", "Off", "50 Hz", "60 Hz"));
        int[] anti = antiModes(); int savedAnti = prefs.getInt("antibanding", anti[0]);
        for (int i=0;i<anti.length;i++) if (anti[i]==savedAnti) antiSpinner.setSelection(i);

        ois = check("Optical stabilization (OIS) (LIVE)", prefs.getBoolean("ois", true));
        eis = check("Electronic stabilization (EIS) (LIVE)", prefs.getBoolean("eis", false));
        torch = check("Camera flash / torch as light (LIVE)", prefs.getBoolean("torch", false));
        showBattery = check("Show phone battery in OBS dock", prefs.getBoolean("show_battery", true));

        TextView note = label("Lens, resolution and FPS require a restart. 60 FPS is always available; higher FPS is shown only when Camera2 reports it. Lens/resolution changes reset zoom to 1× to prevent stale crop. Other controls are live."); note.setTextSize(14);

        Button start = new Button(this); start.setText("START / RESTART STREAM"); root.addView(start);
        start.setOnClickListener(v -> { savePipelineSelections(); Intent i = new Intent(this, StreamingService.class).setAction(StreamingService.ACTION_RESTART); if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i); Toast.makeText(this, "Restarting stream on port 4747", Toast.LENGTH_SHORT).show(); statusText.postDelayed(this::refreshStatus, 800); });
        Button stop = new Button(this); stop.setText("STOP STREAM SERVER"); root.addView(stop);
        stop.setOnClickListener(v -> { startService(new Intent(this, StreamingService.class).setAction(StreamingService.ACTION_STOP)); statusText.postDelayed(this::refreshStatus, 300); });

        TextView help = label("OBS setup");
        help.setText("Add a DroidCam OBS source for video. For controls: OBS → Docks → Custom Browser Docks → http://PHONE_IP:4747/control. Over USB, use http://127.0.0.1:4747/control while the USB source is connected. The OBS dock exposes all Camera2 lenses Android reports, 720p/1080p/2K/4K, 30/60 FPS plus supported higher modes, continuous fractional shutter, manual temperature white balance, battery status and torch.");

        attachListeners();
        updateControlRanges();
        setContentView(sv);
    }

    private void attachListeners() {
        manualExposure.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean("manual_exposure",c).apply();applyLive();});
        manualFocus.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean("manual_focus",c).apply();applyLive();});
        ois.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean("ois",c).apply();applyLive();});
        eis.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean("eis",c).apply();applyLive();});
        torch.setOnCheckedChangeListener((b,c)->{prefs.edit().putBoolean("torch",c).apply();applyLive();});
        showBattery.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("show_battery",c).apply());

        cameraSpinner.setOnItemSelectedListener(new SimpleItemSelected(){@Override public void selected(int pos){if(initializing||pipelineUpdating||pos<0||pos>=lensOptions.size())return;prefs.edit().putString("camera_id",lensOptions.get(pos).selection).putFloat("zoom",1f).apply();zoomBar.setProgress(100);zoomText.setText("Zoom: 1.00× (LIVE)");reloadPipelineOptions(true);configurePreviewBuffer(previewView.getSurfaceTexture());configurePreviewTransform(previewView.getWidth(),previewView.getHeight());markRestartNeeded("Lens changed — zoom reset to 1×; restart to apply");}});
        resolutionSpinner.setOnItemSelectedListener(new SimpleItemSelected(){@Override public void selected(int pos){if(initializing||pipelineUpdating||pos<0||pos>=resolutionOptions.size())return;Size r=resolutionOptions.get(pos);prefs.edit().putInt("width",r.getWidth()).putInt("height",r.getHeight()).putFloat("zoom",1f).apply();zoomBar.setProgress(100);zoomText.setText("Zoom: 1.00× (LIVE)");reloadFpsForResolution();markRestartNeeded("Resolution changed — zoom reset to 1×; restart to apply");}});
        fpsSpinner.setOnItemSelectedListener(new SimpleItemSelected(){@Override public void selected(int pos){if(initializing||pipelineUpdating||pos<0||pos>=fpsOptions.size())return;prefs.edit().putInt("fps",fpsOptions.get(pos)).apply();rebuildShutterRange();markRestartNeeded("FPS changed — restart to apply");}});
        awbSpinner.setOnItemSelectedListener(new SimpleItemSelected(){@Override public void selected(int pos){if(initializing)return;if(pos==7){prefs.edit().putBoolean("manual_wb",true).apply();}else{prefs.edit().putBoolean("manual_wb",false).putInt("awb",awbModes()[pos]).apply();}applyLive();}});
        antiSpinner.setOnItemSelectedListener(new SimpleItemSelected(){@Override public void selected(int pos){if(initializing)return;prefs.edit().putInt("antibanding",antiModes()[pos]).apply();applyLive();}});
    }

    private void loadLenses() {
        try { CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); lensOptions=CameraCatalog.list(cm); }
        catch(Exception ignored){ }
        if(lensOptions.isEmpty()) lensOptions.add(new CameraCatalog.LensOption("cam:0","Camera 0","0",null,CameraCharacteristics.LENS_FACING_EXTERNAL));
    }

    private List<String> labelsForLenses(){List<String>x=new ArrayList<>();for(CameraCatalog.LensOption o:lensOptions)x.add(o.label);return x;}
    private void selectSavedLens(){String saved=prefs.getString("camera_id",null);if(saved==null){try{saved=CameraCatalog.defaultSelection((CameraManager)getSystemService(CAMERA_SERVICE));prefs.edit().putString("camera_id",saved).apply();}catch(Exception ignored){}}for(int i=0;i<lensOptions.size();i++)if(lensOptions.get(i).selection.equals(saved)||lensOptions.get(i).openId.equals(saved)){cameraSpinner.setSelection(i);return;}}

    private CameraCatalog.LensOption currentLens(){int pos=cameraSpinner==null?0:cameraSpinner.getSelectedItemPosition();if(pos<0||pos>=lensOptions.size())pos=0;return lensOptions.get(pos);}

    private void reloadPipelineOptions(boolean cameraChanged) {
        pipelineUpdating=true;
        try {
            CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); CameraCatalog.LensOption lens=currentLens();
            resolutionOptions=CameraCatalog.resolutions(cm,lens);
            List<String> rl=new ArrayList<>(); for(Size r:resolutionOptions) rl.add(CameraCatalog.resolutionLabel(r));
            resolutionSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,rl));
            int sw=prefs.getInt("width",1920), sh=prefs.getInt("height",1080), ri=0;
            for(int i=0;i<resolutionOptions.size();i++) if(resolutionOptions.get(i).getWidth()==sw&&resolutionOptions.get(i).getHeight()==sh){ri=i;break;}
            resolutionSpinner.setSelection(ri);
            Size selectedRes=resolutionOptions.get(ri);
            fpsOptions=CameraCatalog.fpsOptions(cm,lens,selectedRes);
            List<String> fl=new ArrayList<>(); for(Integer f:fpsOptions) fl.add(f+" FPS");
            fpsSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fl));
            int sf=prefs.getInt("fps",60), fi=fpsOptions.indexOf(sf); if(fi<0) fi=fpsOptions.indexOf(60); if(fi<0) fi=0;
            fpsSpinner.setSelection(fi);
            if(cameraChanged){
                prefs.edit().putInt("width",selectedRes.getWidth()).putInt("height",selectedRes.getHeight()).putInt("fps",fpsOptions.get(fi)).putFloat("zoom",1f).apply();
            }
            if(isoBar!=null) updateControlRanges();
            if(shutterBar!=null) rebuildShutterRange();
        } catch(Exception ignored){ }
        pipelineUpdating=false;
    }

    private void reloadFpsForResolution(){
        try{
            pipelineUpdating=true;
            CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);
            int rp=resolutionSpinner.getSelectedItemPosition();
            Size r=(rp>=0&&rp<resolutionOptions.size())?resolutionOptions.get(rp):new Size(1920,1080);
            fpsOptions=CameraCatalog.fpsOptions(cm,currentLens(),r);
            List<String> fl=new ArrayList<>();for(Integer f:fpsOptions)fl.add(f+" FPS");
            int saved=prefs.getInt("fps",60);fpsSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fl));
            int fi=fpsOptions.indexOf(saved);if(fi<0)fi=fpsOptions.indexOf(60);if(fi<0)fi=0;fpsSpinner.setSelection(fi);
            prefs.edit().putInt("fps",fpsOptions.get(fi)).apply();
            rebuildShutterRange();
        }catch(Exception ignored){}
        pipelineUpdating=false;
    }

    private void updateControlRanges(){
        try{
            CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);CameraCharacteristics c=CameraCatalog.selectedCharacteristics(cm,currentLens());
            Range<Integer> ir=c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);if(ir!=null&&isoBar!=null){isoBar.setMin(ir.getLower());isoBar.setMax(ir.getUpper());isoBar.setProgress(Math.max(ir.getLower(),Math.min(prefs.getInt("iso",200),ir.getUpper())));}
            Float mf=c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);if(mf!=null&&mf>0&&focusBar!=null)focusBar.setMax(Math.max(1,(int)(mf*100)));
            float minz=1f,mz=10f;if(Build.VERSION.SDK_INT>=30&&currentLens().physicalId==null){Range<Float>zr=cm.getCameraCharacteristics(currentLens().openId).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);if(zr!=null){minz=zr.getLower();mz=zr.getUpper();}}else{Float z=c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);if(z!=null)mz=z;}
            if(zoomBar!=null){zoomBar.setMin(Math.max(10,(int)(minz*100)));zoomBar.setMax(Math.max(100,(int)(mz*100)));float saved=prefs.getFloat("zoom",1f);saved=Math.max(minz,Math.min(saved,mz));prefs.edit().putFloat("zoom",saved).apply();zoomBar.setProgress((int)(saved*100));zoomText.setText(String.format(Locale.US,"Zoom: %.2f× (LIVE)",saved));}
            Boolean fa=cm.getCameraCharacteristics(currentLens().openId).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);if(torch!=null)torch.setEnabled(Boolean.TRUE.equals(fa));
        }catch(Exception ignored){ }
    }

    private void rebuildShutterRange(){
        if(shutterBar==null)return;
        long minNs=100_000L,maxNs=(long)(1_000_000_000L/Math.max(1,prefs.getInt("fps",60)));
        try{CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);Range<Long>er=CameraCatalog.selectedCharacteristics(cm,currentLens()).get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);if(er!=null){minNs=Math.max(1L,er.getLower());maxNs=Math.min(maxNs,er.getUpper());}}catch(Exception ignored){ }
        if(maxNs<minNs)maxNs=minNs;shutterMinNs=minNs;shutterMaxNs=maxNs;
        long cur=Math.max(minNs,Math.min(prefs.getLong("exposure_ns",8_333_333L),maxNs));prefs.edit().putLong("exposure_ns",cur).apply();
        shutterBar.setProgress(shutterToSlider(cur));shutterText.setText("Shutter: "+shutterLabel(cur)+" (LIVE)");
    }

    private long shutterFromSlider(int progress){
        if(shutterMaxNs<=shutterMinNs)return shutterMinNs;
        double t=Math.max(0,Math.min(1000,progress))/1000.0;
        double ln=Math.log(shutterMinNs)+t*(Math.log(shutterMaxNs)-Math.log(shutterMinNs));
        return Math.max(shutterMinNs,Math.min(shutterMaxNs,Math.round(Math.exp(ln))));
    }

    private int shutterToSlider(long ns){
        if(shutterMaxNs<=shutterMinNs)return 0;
        double t=(Math.log(Math.max(shutterMinNs,Math.min(ns,shutterMaxNs)))-Math.log(shutterMinNs))/(Math.log(shutterMaxNs)-Math.log(shutterMinNs));
        return (int)Math.round(Math.max(0,Math.min(1,t))*1000.0);
    }

    private static String shutterLabel(long ns){
        double sec=ns/1e9;
        if(sec<0.999){double d=1.0/sec;if(d>=1)return "1/"+Math.max(1,Math.round(d))+" s";}
        return String.format(Locale.US,sec<10?"%.2f s":"%.1f s",sec);
    }

    private List<String> wbLabels(){return list("Auto","Incandescent","Fluorescent","Warm fluorescent","Daylight","Cloudy daylight","Shade","Manual temperature (K)");}
    private void selectSavedWb(){if(prefs.getBoolean("manual_wb",false)){awbSpinner.setSelection(7);return;}int[]m=awbModes();int saved=prefs.getInt("awb",m[0]);for(int i=0;i<m.length;i++)if(m[i]==saved){awbSpinner.setSelection(i);return;}}

    private int[] awbModes(){return new int[]{CaptureRequest.CONTROL_AWB_MODE_AUTO,CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_SHADE};}
    private int[] antiModes(){return new int[]{CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_OFF,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_50HZ,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ};}

    private void savePipelineSelections(){
        if(!lensOptions.isEmpty())prefs.edit().putString("camera_id",currentLens().selection).apply();
        int rp=resolutionSpinner.getSelectedItemPosition();if(rp>=0&&rp<resolutionOptions.size()){Size s=resolutionOptions.get(rp);prefs.edit().putInt("width",s.getWidth()).putInt("height",s.getHeight()).apply();}
        int fp=fpsSpinner.getSelectedItemPosition();if(fp>=0&&fp<fpsOptions.size())prefs.edit().putInt("fps",fpsOptions.get(fp)).apply();
    }

    private void configurePreviewBuffer(SurfaceTexture st){if(st==null)return;previewBufferW=640;previewBufferH=360;try{CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);StreamConfigurationMap map=cm.getCameraCharacteristics(currentLens().openId).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);if(map!=null){Size[]sizes=map.getOutputSizes(SurfaceTexture.class);Size best=null;if(sizes!=null)for(Size s:sizes){float r=s.getWidth()/(float)s.getHeight();if(Math.abs(r-16f/9f)>.08f||s.getWidth()>1280)continue;if(best==null||s.getWidth()>best.getWidth())best=s;}if(best!=null){previewBufferW=best.getWidth();previewBufferH=best.getHeight();}}}catch(Exception ignored){}st.setDefaultBufferSize(previewBufferW,previewBufferH);}

    private void configurePreviewTransform(int viewW,int viewH){
        if(previewView==null||viewW<=0||viewH<=0)return;
        try{
            CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);CameraCharacteristics c=cm.getCameraCharacteristics(currentLens().openId);Integer so=c.get(CameraCharacteristics.SENSOR_ORIENTATION);Integer facing=c.get(CameraCharacteristics.LENS_FACING);int rotation=so==null?90:so;
            Matrix m=new Matrix();float cx=viewW/2f,cy=viewH/2f;RectF view=new RectF(0,0,viewW,viewH);RectF buffer;
            if(rotation==90||rotation==270)buffer=new RectF(0,0,previewBufferH,previewBufferW);else buffer=new RectF(0,0,previewBufferW,previewBufferH);
            buffer.offset(cx-buffer.centerX(),cy-buffer.centerY());m.setRectToRect(view,buffer,Matrix.ScaleToFit.FILL);float scale=Math.max(viewW/buffer.width(),viewH/buffer.height());m.postScale(scale,scale,cx,cy);m.postRotate(rotation,cx,cy);if(facing!=null&&facing==CameraCharacteristics.LENS_FACING_FRONT)m.postScale(-1,1,cx,cy);previewView.setTransform(m);
        }catch(Exception ignored){ }
    }

    private void applyLive(){if(initializing)return;if(bound&&service!=null&&service.isRunning()){service.applySettingsLive();statusText.setText("Status: STREAMING • live setting applied");}}
    private void attachPreviewIfReady(){if(bound&&service!=null&&previewSurface!=null&&previewSurface.isValid())service.setPreviewSurface(previewSurface);}
    private void refreshStatus(){statusText.setText(service!=null&&service.isRunning()?"Status: STREAMING • live controls active":"Status: stopped");}
    private void markRestartNeeded(String m){statusText.setText((service!=null&&service.isRunning()?"Status: STREAMING • ":"Status: ")+m);}

    private CheckBox check(String t,boolean c){CheckBox x=new CheckBox(this);x.setText(t);x.setChecked(c);root.addView(x);return x;}
    private Spinner spinner(List<String> values){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values));root.addView(s);return s;}
    interface SeekListener{void onValue(int value);} private SeekBar seek(int min,int max,int value,SeekListener l){SeekBar s=new SeekBar(this);s.setMin(min);s.setMax(max);s.setProgress(Math.max(min,Math.min(value,max)));root.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){@Override public void onProgressChanged(SeekBar b,int p,boolean fromUser){if(fromUser)l.onValue(p);}@Override public void onStartTrackingTouch(SeekBar b){}@Override public void onStopTrackingTouch(SeekBar b){}});return s;}
    private abstract static class SimpleItemSelected implements AdapterView.OnItemSelectedListener{abstract void selected(int position);@Override public void onItemSelected(AdapterView<?>p,android.view.View v,int pos,long id){selected(pos);}@Override public void onNothingSelected(AdapterView<?>p){}}
    @SafeVarargs private final <T> List<T> list(T...x){List<T>r=new ArrayList<>();Collections.addAll(r,x);return r;}
    private void updateBitrateLabel(){bitrateText.setText(String.format(Locale.US,"Bitrate: %.1f Mbps (LIVE)",prefs.getInt("bitrate",20_000_000)/1e6));}

    private String primaryWifiIpv4(){try{String fallback=null;for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())){if(!ni.isUp()||ni.isLoopback())continue;for(java.net.InetAddress a:Collections.list(ni.getInetAddresses())){if(a.isLoopbackAddress()||!(a instanceof Inet4Address))continue;String ip=a.getHostAddress(),n=ni.getName().toLowerCase(Locale.US);if(n.startsWith("wlan")||n.startsWith("wifi"))return ip;if(fallback==null&&!n.startsWith("tun")&&!n.startsWith("wg"))fallback=ip;}}return fallback==null?"PHONE_IP":fallback;}catch(Exception ignored){}return "PHONE_IP";}
    private String localIpv4(){try{List<String>wifi=new ArrayList<>(),other=new ArrayList<>();for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())){if(!ni.isUp()||ni.isLoopback())continue;for(java.net.InetAddress a:Collections.list(ni.getInetAddresses())){if(a.isLoopbackAddress()||!(a instanceof Inet4Address))continue;String item=ni.getName()+"="+a.getHostAddress(),n=ni.getName().toLowerCase(Locale.US);if(n.startsWith("wlan")||n.startsWith("wifi"))wifi.add(item);else other.add(item);}}wifi.addAll(other);return wifi.isEmpty()?"phone-IP":String.join("  |  ",wifi);}catch(Exception ignored){}return "phone-IP";}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
