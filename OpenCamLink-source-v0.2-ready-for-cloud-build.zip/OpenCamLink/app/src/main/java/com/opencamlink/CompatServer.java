package com.opencamlink;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class CompatServer {
    private static final String TAG = "OpenCamLink.Server";
    private final int port;
    private final VideoBroadcaster broadcaster;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private ServerSocket server;

    CompatServer(int port, VideoBroadcaster broadcaster) {
        this.port = port;
        this.broadcaster = broadcaster;
    }

    void start() throws Exception {
        server = new ServerSocket(port);
        server.setReuseAddress(true);
        running = true;
        pool.execute(() -> {
            while (running) {
                try {
                    Socket s = server.accept();
                    s.setTcpNoDelay(true);
                    s.setKeepAlive(true);
                    pool.execute(() -> handle(s));
                } catch (Exception e) {
                    if (running) Log.w(TAG, "accept failed", e);
                }
            }
        });
    }

    private void handle(Socket s) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII));
            String request = br.readLine();
            if (request == null) { s.close(); return; }
            String path = request.split(" ").length > 1 ? request.split(" ")[1] : "/";
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) { }
            OutputStream out = s.getOutputStream();

            if (path.startsWith("/v5/video/avc/")) {
                Protocol.writeHttpOk(out);
                ClientWriter client = new ClientWriter(s);
                broadcaster.add(client);
                try { client.run(); } finally { broadcaster.remove(client); }
                return;
            }

            if (path.equals("/") || path.startsWith("/status")) {
                String body = "OpenCam Link\nH.264 compatibility server active on port " + port + "\n";
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                String h = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes(StandardCharsets.US_ASCII));
                out.write(b); out.flush(); s.close(); return;
            }

            Protocol.writeHttpError(out, 404, "Not Found");
            s.close();
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) {}
            Log.i(TAG, "connection ended: " + e.getMessage());
        }
    }

    void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
        broadcaster.closeAll();
    }
}
