package com.opencamlink;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private final List<String> cameraIds = new ArrayList<>();
    private final List<String> cameraLabels = new ArrayList<>();
    private Spinner cameraSpinner, fpsSpinner, bitrateSpinner, awbSpinner, antiSpinner;
    private CheckBox manualExposure, manualFocus, ois, eis;
    private SeekBar isoBar, shutterBar, aeBar, focusBar, zoomBar;
    private TextView isoText, shutterText, aeText, focusText, zoomText, ipText;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        requestPermissionsIfNeeded();
        buildUi();
    }

    private void requestPermissionsIfNeeded() {
        List<String> req = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) req.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            req.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), 100);
    }

    private TextView label(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(16); v.setPadding(0, 16, 0, 6); root.addView(v); return v;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28, 28, 28, 40); sv.addView(root);
        TextView title = new TextView(this); title.setText("OpenCam Link"); title.setTextSize(28); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Independent 1080p H.264 camera streamer for OBS compatibility mode. No watermark."); root.addView(sub);
        ipText = label("Wi-Fi: " + localIpv4() + ":4747   |   USB: use OBS plugin USB mode (ADB forwarding)");

        loadCameras();
        label("Camera");
        cameraSpinner = spinner(cameraLabels);
        String savedCam = prefs.getString("camera_id", null);
        if (savedCam != null && cameraIds.contains(savedCam)) cameraSpinner.setSelection(cameraIds.indexOf(savedCam));

        label("Frame rate");
        fpsSpinner = spinner(Arrays.asList("30 FPS", "60 FPS")); fpsSpinner.setSelection(prefs.getInt("fps",60)==60?1:0);
        label("Bitrate");
        bitrateSpinner = spinner(Arrays.asList("8 Mbps", "12 Mbps", "16 Mbps", "20 Mbps", "24 Mbps", "32 Mbps"));
        int[] bitrates = {8,12,16,20,24,32}; int savedB = prefs.getInt("bitrate",20_000_000)/1_000_000; int bi=3;
        for (int i=0;i<bitrates.length;i++) if (bitrates[i]==savedB) bi=i; bitrateSpinner.setSelection(bi);

        manualExposure = check("Manual exposure", prefs.getBoolean("manual_exposure", false));
        isoText = label(""); isoBar = seek(50, 3200, prefs.getInt("iso",200), v -> { prefs.edit().putInt("iso",v).apply(); isoText.setText("ISO: "+v); update(); }); isoText.setText("ISO: "+prefs.getInt("iso",200));
        shutterText = label(""); shutterBar = seek(1, 100, shutterMsToProgress(prefs.getLong("exposure_ns",8_333_333L)), v -> { double ms = progressToShutterMs(v); prefs.edit().putLong("exposure_ns",(long)(ms*1_000_000)).apply(); shutterText.setText(String.format("Shutter: %.2f ms (≈1/%.0f)",ms,1000.0/ms)); update(); }); updateShutterLabel();
        aeText = label(""); aeBar = seek(-6,6,prefs.getInt("ae_comp",0), v -> { prefs.edit().putInt("ae_comp",v).apply(); aeText.setText("Auto exposure compensation: "+v); update(); }); aeText.setText("Auto exposure compensation: "+prefs.getInt("ae_comp",0));

        label("White balance"); awbSpinner = spinner(Arrays.asList("Auto","Incandescent","Fluorescent","Warm fluorescent","Daylight","Cloudy daylight","Shade"));
        int[] awbs = {CaptureRequest.CONTROL_AWB_MODE_AUTO,CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_SHADE};
        int savedAwb=prefs.getInt("awb",awbs[0]); for(int i=0;i<awbs.length;i++) if(awbs[i]==savedAwb) awbSpinner.setSelection(i);

        manualFocus = check("Manual focus", prefs.getBoolean("manual_focus", false));
        focusText = label(""); focusBar = seek(0,1000,(int)(prefs.getFloat("focus_distance",0f)*100), v -> { float d=v/100f; prefs.edit().putFloat("focus_distance",d).apply(); focusText.setText(String.format("Focus distance: %.2f diopters",d)); update(); }); focusText.setText(String.format("Focus distance: %.2f diopters",focusBar.getProgress()/100f));
        zoomText = label(""); zoomBar = seek(100,1000,(int)(prefs.getFloat("zoom",1f)*100), v -> { float z=v/100f; prefs.edit().putFloat("zoom",z).apply(); zoomText.setText(String.format("Zoom: %.2fx",z)); update(); }); zoomText.setText(String.format("Zoom: %.2fx",zoomBar.getProgress()/100f));

        label("Anti-flicker"); antiSpinner = spinner(Arrays.asList("Auto","Off","50 Hz","60 Hz"));
        int[] antis={CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_OFF,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_50HZ,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ};
        int savedAnti=prefs.getInt("antibanding",antis[0]); for(int i=0;i<antis.length;i++) if(antis[i]==savedAnti) antiSpinner.setSelection(i);
        ois = check("Optical stabilization (OIS)", prefs.getBoolean("ois", true));
        eis = check("Electronic video stabilization (EIS)", prefs.getBoolean("eis", false));

        Button apply = new Button(this); apply.setText("APPLY SETTINGS"); root.addView(apply); apply.setOnClickListener(v -> { saveSelections(); update(); Toast.makeText(this,"Settings applied",Toast.LENGTH_SHORT).show(); });
        Button start = new Button(this); start.setText("START 1080P STREAM SERVER"); root.addView(start); start.setOnClickListener(v -> { saveSelections(); Intent i=new Intent(this,StreamingService.class).setAction(StreamingService.ACTION_START); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); Toast.makeText(this,"Server starting on port 4747",Toast.LENGTH_SHORT).show(); });
        Button stop = new Button(this); stop.setText("STOP STREAM SERVER"); root.addView(stop); stop.setOnClickListener(v -> startService(new Intent(this,StreamingService.class).setAction(StreamingService.ACTION_STOP)));

        TextView help = label("OBS setup");
        help.setText("OBS → Add Source → DroidCam OBS. For Wi-Fi, enable ‘Use WiFi IP’ and enter the phone IP shown above. For USB, enable USB debugging, connect the phone, press Refresh Device List and select it. Select AVC/H.264, 1920×1080. The phone encoder target is controlled here (30/60 FPS and bitrate).\n\nCompatibility mode uses only the receiver's public network interface. This app contains no DroidCam code, logos, assets, licensing logic, or watermark-removal bypass.");

        manualExposure.setOnCheckedChangeListener((b1,c)->{prefs.edit().putBoolean("manual_exposure",c).apply();update();});
        manualFocus.setOnCheckedChangeListener((b1,c)->{prefs.edit().putBoolean("manual_focus",c).apply();update();});
        ois.setOnCheckedChangeListener((b1,c)->{prefs.edit().putBoolean("ois",c).apply();update();});
        eis.setOnCheckedChangeListener((b1,c)->{prefs.edit().putBoolean("eis",c).apply();update();});
        setContentView(sv);
    }

    private void saveSelections() {
        int[] bitrates={8,12,16,20,24,32};
        int[] awbs={CaptureRequest.CONTROL_AWB_MODE_AUTO,CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT,CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,CaptureRequest.CONTROL_AWB_MODE_SHADE};
        int[] antis={CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_OFF,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_50HZ,CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ};
        SharedPreferences.Editor e=prefs.edit();
        if(!cameraIds.isEmpty()) e.putString("camera_id",cameraIds.get(cameraSpinner.getSelectedItemPosition()));
        e.putInt("fps",fpsSpinner.getSelectedItemPosition()==1?60:30);
        e.putInt("bitrate",bitrates[bitrateSpinner.getSelectedItemPosition()]*1_000_000);
        e.putInt("awb",awbs[awbSpinner.getSelectedItemPosition()]);
        e.putInt("antibanding",antis[antiSpinner.getSelectedItemPosition()]);
        e.apply();
    }

    private void update() { try { startService(new Intent(this,StreamingService.class).setAction(StreamingService.ACTION_UPDATE)); } catch(Exception ignored){} }
    private CheckBox check(String t, boolean c){ CheckBox x=new CheckBox(this);x.setText(t);x.setChecked(c);root.addView(x);return x; }
    private Spinner spinner(List<String> values){ Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values));root.addView(s);return s; }
    interface SeekListener{void onValue(int value);} private SeekBar seek(int min,int max,int value,SeekListener l){SeekBar s=new SeekBar(this); if(Build.VERSION.SDK_INT>=26){s.setMin(min);s.setMax(max);s.setProgress(value);}else{s.setMax(max-min);s.setProgress(value-min);} root.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){l.onValue(Build.VERSION.SDK_INT>=26?p:p+min);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});return s;}

    private void loadCameras(){ try {CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE); for(String id:cm.getCameraIdList()){CameraCharacteristics c=cm.getCameraCharacteristics(id);Integer f=c.get(CameraCharacteristics.LENS_FACING);String face=f==null?"Camera":(f==CameraCharacteristics.LENS_FACING_FRONT?"Front":f==CameraCharacteristics.LENS_FACING_BACK?"Rear":"External");Float focal=null;float[] fl=c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);if(fl!=null&&fl.length>0)focal=fl[0];cameraIds.add(id);cameraLabels.add(face+" — ID "+id+(focal==null?"":String.format(" — %.1f mm",focal)));}}catch(Exception e){cameraIds.add("0");cameraLabels.add("Camera ID 0");}}
    private String localIpv4(){ try {for(NetworkInterface ni:Collections.list(NetworkInterface.getNetworkInterfaces())) for(java.net.InetAddress a:Collections.list(ni.getInetAddresses())) if(!a.isLoopbackAddress()&&a instanceof Inet4Address) return a.getHostAddress();}catch(Exception ignored){}return "phone-IP"; }
    private int shutterMsToProgress(long ns){double ms=ns/1_000_000.0; return Math.max(1,Math.min(100,(int)Math.round(ms)));}
    private double progressToShutterMs(int p){return Math.max(1,p);} private void updateShutterLabel(){double ms=progressToShutterMs(shutterBar.getProgress());shutterText.setText(String.format("Shutter: %.2f ms (≈1/%.0f)",ms,1000.0/ms));}
}
