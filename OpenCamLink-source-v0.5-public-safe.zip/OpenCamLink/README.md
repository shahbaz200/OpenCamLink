# OpenCam Link v0.5

Independent Android Camera2 -> H.264 sender compatible with the public network interface used by the DroidCam OBS receiver plugin.

## v0.5 improvements

- Built-in **OBS Studio control dock** served by the phone at `http://PHONE_IP:4747/control`.
- The same control page can normally be reached through the plugin's USB/ADB tunnel at `http://127.0.0.1:4747/control` while the USB source is connected.
- Live OBS controls for ISO, shutter, AE compensation, white balance, manual focus, focus distance, zoom, anti-flicker, OIS, EIS and bitrate.
- Camera and FPS can be selected in the dock and applied using **Apply camera/FPS & restart stream**.
- No separate Windows helper or OBS plugin modification is required; the dock is a normal OBS Custom Browser Dock.
- Phone UI is forced to portrait and the local preview frame is portrait (9:16) so the preview is no longer stretched into a landscape box.
- Existing Wi-Fi and USB/ADB video compatibility remains on port 4747.
- Existing phone-side live controls remain available.

Audio is still intentionally disabled in this build.

## Add the control panel to OBS Studio

1. Start OpenCam Link on the phone.
2. In OBS Studio open **Docks -> Custom Browser Docks**.
3. Name the dock `OpenCam Link`.
4. For Wi-Fi use `http://PHONE_IP:4747/control` (replace `PHONE_IP` with the phone's WLAN address shown in the app).
5. For USB, while the DroidCam OBS USB source is connected, try `http://127.0.0.1:4747/control`. If the receiver had to choose a different local ADB-forward port, use the Wi-Fi URL for controls while keeping video on USB.

This is an independent implementation. It contains no DroidCam branding, assets, Android application code, licensing logic or entitlement bypass.
