package com.opencamlink;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Range;
import android.util.Log;
import android.view.Surface;

import java.util.Map;
import java.util.Locale;

public class StreamingService extends Service {
    public static final String ACTION_START = "com.opencamlink.START";
    public static final String ACTION_RESTART = "com.opencamlink.RESTART";
    public static final String ACTION_STOP = "com.opencamlink.STOP";
    public static final String ACTION_UPDATE = "com.opencamlink.UPDATE";

    private static final String TAG = "OpenCamLink.Service";
    private static final String CHANNEL = "streaming";

    private final VideoBroadcaster broadcaster = new VideoBroadcaster();
    private final LocalBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CameraController camera;
    private CompatServer server;
    private NsdAdvertiser nsd;
    private Surface previewSurface;
    private volatile boolean running;

    public final class LocalBinder extends Binder {
        public StreamingService getService() { return StreamingService.this; }
    }

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopEverything(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_UPDATE.equals(action)) {
            applySettingsLive();
            return START_STICKY;
        }

        startForeground(47, buildNotification());

        if (ACTION_RESTART.equals(action)) {
            stopEverything(false);
            startEverything();
            return START_STICKY;
        }

        if (!running) startEverything();
        return START_STICKY;
    }

    public boolean isRunning() { return running; }

    public void setPreviewSurface(Surface surface) {
        previewSurface = surface;
        if (camera != null) camera.setPreviewSurface(surface);
    }

    public void clearPreviewSurface(Surface surface) {
        if (previewSurface == surface) {
            previewSurface = null;
            if (camera != null) camera.setPreviewSurface(null);
        }
    }

    private void startEverything() {
        try {
            SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
            int port = p.getInt("port", 4747);
            int fps = p.getInt("fps", 60);
            int bitrate = p.getInt("bitrate", 20_000_000);
            String cameraId = p.getString("camera_id", null);

            camera = new CameraController(this, broadcaster);
            camera.configure(cameraId, 1920, 1080, fps, bitrate);
            camera.setPreviewSurface(previewSurface);
            camera.start();
            applySettingsLive();

            server = new CompatServer(port, broadcaster, this);
            server.start();
            nsd = new NsdAdvertiser(this);
            nsd.start(port);
            running = true;
            Log.i(TAG, "streaming/control server started on port " + port);
        } catch (Exception e) {
            Log.e(TAG, "failed to start", e);
            stopEverything(true);
            stopSelf();
        }
    }

    public void applySettingsLive() {
        if (camera == null) return;
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        boolean manualExposure = p.getBoolean("manual_exposure", false);
        int iso = p.getInt("iso", 200);
        long exposureNs = p.getLong("exposure_ns", 8_333_333L);
        int aeComp = p.getInt("ae_comp", 0);
        int awb = p.getInt("awb", CaptureRequest.CONTROL_AWB_MODE_AUTO);
        boolean manualFocus = p.getBoolean("manual_focus", false);
        float focusDistance = p.getFloat("focus_distance", 0f);
        float zoom = p.getFloat("zoom", 1f);
        int antibanding = p.getInt("antibanding", CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO);
        boolean ois = p.getBoolean("ois", true);
        boolean eis = p.getBoolean("eis", false);
        int bitrate = p.getInt("bitrate", 20_000_000);
        camera.updateControls(manualExposure, iso, exposureNs, aeComp, awb, manualFocus,
                focusDistance, zoom, antibanding, ois, eis, bitrate);
    }

    /** Called by the built-in OBS browser dock API. */
    void applyControlValues(Map<String, String> values) {
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit();
        for (Map.Entry<String, String> entry : values.entrySet()) {
            String k = entry.getKey();
            String v = entry.getValue();
            try {
                switch (k) {
                    case "manual_exposure": e.putBoolean(k, bool(v)); break;
                    case "iso": e.putInt(k, Integer.parseInt(v)); break;
                    case "exposure_ms": e.putLong("exposure_ns", (long) (Double.parseDouble(v) * 1_000_000.0)); break;
                    case "exposure_ns": e.putLong(k, Long.parseLong(v)); break;
                    case "ae_comp": e.putInt(k, Integer.parseInt(v)); break;
                    case "awb": e.putInt(k, Integer.parseInt(v)); break;
                    case "manual_focus": e.putBoolean(k, bool(v)); break;
                    case "focus_distance": e.putFloat(k, Float.parseFloat(v)); break;
                    case "zoom": e.putFloat(k, Float.parseFloat(v)); break;
                    case "antibanding": e.putInt(k, Integer.parseInt(v)); break;
                    case "ois": e.putBoolean(k, bool(v)); break;
                    case "eis": e.putBoolean(k, bool(v)); break;
                    case "bitrate": e.putInt(k, Integer.parseInt(v)); break;
                    case "camera_id": e.putString(k, v); break;
                    case "fps": e.putInt(k, Integer.parseInt(v)); break;
                }
            } catch (Exception ignored) { }
        }
        e.apply();
        applySettingsLive();
    }

    void restartFromControlAsync() {
        mainHandler.postDelayed(() -> {
            if (!running) return;
            stopEverything(false);
            startEverything();
        }, 350);
    }

    String controlStateJson() {
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        String cameraId = p.getString("camera_id", null);
        CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        StringBuilder camerasJson = new StringBuilder("[");
        float maxZoom = 10f;
        float maxFocus = 10f;
        int isoMin = 50, isoMax = 3200;
        try {
            String[] ids = cm.getCameraIdList();
            if (cameraId == null && ids.length > 0) cameraId = chooseDefaultCameraId(cm, ids);
            for (int i = 0; i < ids.length; i++) {
                String id = ids[i];
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                if (i > 0) camerasJson.append(',');
                camerasJson.append("{\"id\":\"").append(json(id)).append("\",\"label\":\"")
                        .append(json(cameraLabel(id, c))).append("\"}");
                if (id.equals(cameraId)) {
                    Float mz = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                    Float mf = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
                    Range<Integer> ir = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                    if (mz != null && mz > 1f) maxZoom = mz;
                    if (mf != null && mf > 0f) maxFocus = mf;
                    if (ir != null) { isoMin = ir.getLower(); isoMax = ir.getUpper(); }
                }
            }
        } catch (Exception ignored) { }
        camerasJson.append(']');

        return "{" +
                "\"version\":\"0.5.0\"," +
                "\"running\":" + running + ',' +
                "\"camera_id\":\"" + json(cameraId == null ? "0" : cameraId) + "\"," +
                "\"fps\":" + p.getInt("fps", 60) + ',' +
                "\"bitrate\":" + p.getInt("bitrate", 20_000_000) + ',' +
                "\"manual_exposure\":" + p.getBoolean("manual_exposure", false) + ',' +
                "\"iso\":" + p.getInt("iso", 200) + ',' +
                "\"exposure_ns\":" + p.getLong("exposure_ns", 8_333_333L) + ',' +
                "\"ae_comp\":" + p.getInt("ae_comp", 0) + ',' +
                "\"awb\":" + p.getInt("awb", CaptureRequest.CONTROL_AWB_MODE_AUTO) + ',' +
                "\"manual_focus\":" + p.getBoolean("manual_focus", false) + ',' +
                "\"focus_distance\":" + fmt(p.getFloat("focus_distance", 0f)) + ',' +
                "\"zoom\":" + fmt(p.getFloat("zoom", 1f)) + ',' +
                "\"antibanding\":" + p.getInt("antibanding", CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO) + ',' +
                "\"ois\":" + p.getBoolean("ois", true) + ',' +
                "\"eis\":" + p.getBoolean("eis", false) + ',' +
                "\"max_zoom\":" + fmt(maxZoom) + ',' +
                "\"max_focus\":" + fmt(maxFocus) + ',' +
                "\"iso_min\":" + isoMin + ',' +
                "\"iso_max\":" + isoMax + ',' +
                "\"cameras\":" + camerasJson +
                "}";
    }

    private static boolean bool(String v) {
        return "1".equals(v) || "true".equalsIgnoreCase(v) || "on".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
    }

    private static String fmt(float v) { return String.format(Locale.US, "%.4f", v); }

    private static String json(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private String chooseDefaultCameraId(CameraManager cm, String[] ids) {
        try {
            for (String id : ids) {
                Integer facing = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
            }
        } catch (Exception ignored) { }
        return ids.length == 0 ? "0" : ids[0];
    }

    private static String cameraLabel(String id, CameraCharacteristics c) {
        Integer f = c.get(CameraCharacteristics.LENS_FACING);
        String face = f == null ? "Camera" : (f == CameraCharacteristics.LENS_FACING_FRONT ? "Front" : f == CameraCharacteristics.LENS_FACING_BACK ? "Rear" : "External");
        float[] fl = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        String focal = (fl != null && fl.length > 0) ? String.format(Locale.US, " · %.1f mm", fl[0]) : "";
        return face + " · ID " + id + focal;
    }

    private void stopEverything(boolean removeForeground) {
        running = false;
        if (nsd != null) { nsd.stop(); nsd = null; }
        if (server != null) { server.stop(); server = null; }
        if (camera != null) { camera.stop(); camera = null; }
        broadcaster.closeAll();
        if (removeForeground) {
            try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        }
    }

    @Override public void onDestroy() {
        stopEverything(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Camera streaming", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("OpenCam Link")
                .setContentText("1080p camera + OBS control server is running")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();
    }
}
