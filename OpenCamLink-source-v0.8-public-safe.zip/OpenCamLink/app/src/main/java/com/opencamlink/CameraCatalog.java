package com.opencamlink;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Range;
import android.util.Size;
import android.util.SizeF;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/** Camera/lens discovery helpers, including logical multi-camera physical lenses. */
final class CameraCatalog {
    static final class LensOption {
        final String selection;
        final String label;
        final String openId;
        final String physicalId;
        final int facing;
        /** User-facing optical baseline relative to the primary rear wide camera (0.6x, 1x, 3x, 10x...). */
        final float baseZoom;

        LensOption(String selection, String label, String openId, String physicalId, int facing, float baseZoom) {
            this.selection = selection;
            this.label = label;
            this.openId = openId;
            this.physicalId = physicalId;
            this.facing = facing;
            this.baseZoom = baseZoom;
        }
    }

    private CameraCatalog() { }

    static List<LensOption> list(CameraManager cm) {
        List<LensOption> out = new ArrayList<>();
        try {
            String[] publicIds = cm.getCameraIdList();
            Set<String> referencedPhysical = new HashSet<>();
            if (Build.VERSION.SDK_INT >= 28) {
                for (String id : publicIds) {
                    try { referencedPhysical.addAll(cm.getCameraCharacteristics(id).getPhysicalCameraIds()); }
                    catch (Exception ignored) { }
                }
            }

            for (String id : publicIds) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                int facing = facing(c);
                Set<String> physical = Build.VERSION.SDK_INT >= 28 ? c.getPhysicalCameraIds() : Collections.emptySet();
                boolean logical = isLogical(c) && !physical.isEmpty();

                if (logical) {
                    String face = faceName(facing);
                    out.add(new LensOption("auto:" + id,
                            face + " Auto — switches physical lenses with zoom",
                            id, null, facing, 1f));

                    List<PhysicalInfo> infos = new ArrayList<>();
                    for (String pid : physical) {
                        try {
                            CameraCharacteristics pc = cm.getCameraCharacteristics(pid);
                            infos.add(new PhysicalInfo(pid, pc, equivalentFocalMm(pc)));
                        } catch (Exception e) {
                            infos.add(new PhysicalInfo(pid, null, Float.NaN));
                        }
                    }
                    float primaryEq = choosePrimaryEquivalent(infos);
                    infos.sort(Comparator.comparingDouble(a -> Float.isNaN(a.eqMm) ? 99999 : a.eqMm));
                    for (PhysicalInfo info : infos) {
                        float base = physicalBaseZoom(facing, info, primaryEq);
                        String label = physicalLabel(facing, info, primaryEq, base);
                        out.add(new LensOption("phys:" + id + ":" + info.id, label, id, info.id, facing, base));
                    }
                } else if (!referencedPhysical.contains(id)) {
                    out.add(new LensOption("cam:" + id, directLabel(id, c), id, null, facing, 1f));
                }
            }

            if (out.isEmpty()) {
                for (String id : publicIds) {
                    CameraCharacteristics c = cm.getCameraCharacteristics(id);
                    out.add(new LensOption("cam:" + id, directLabel(id, c), id, null, facing(c), 1f));
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    static String defaultSelection(CameraManager cm) {
        List<LensOption> options = list(cm);
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_FRONT && o.selection.startsWith("auto:")) return o.selection;
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_FRONT) return o.selection;
        for (LensOption o : options) if (o.facing == CameraCharacteristics.LENS_FACING_BACK && o.selection.startsWith("auto:")) return o.selection;
        return options.isEmpty() ? "cam:0" : options.get(0).selection;
    }

    static LensOption resolve(CameraManager cm, String selection) {
        List<LensOption> options = list(cm);
        if (selection != null) {
            for (LensOption o : options) if (selection.equals(o.selection)) return o;
            for (LensOption o : options) if (selection.equals(o.openId) && o.physicalId == null) return o;
        }
        String def = defaultSelection(cm);
        for (LensOption o : options) if (def.equals(o.selection)) return o;
        return options.isEmpty() ? new LensOption("cam:0", "Camera 0", "0", null,
                CameraCharacteristics.LENS_FACING_EXTERNAL, 1f) : options.get(0);
    }

    static CameraCharacteristics selectedCharacteristics(CameraManager cm, LensOption option) throws Exception {
        if (option.physicalId != null) {
            try { return cm.getCameraCharacteristics(option.physicalId); } catch (Exception ignored) { }
        }
        return cm.getCameraCharacteristics(option.openId);
    }

    static List<LensOption> physicalLenses(CameraManager cm, String logicalId) {
        List<LensOption> out = new ArrayList<>();
        for (LensOption o : list(cm)) {
            if (logicalId.equals(o.openId) && o.physicalId != null) out.add(o);
        }
        out.sort(Comparator.comparingDouble(o -> o.baseZoom));
        return out;
    }

    /** Pick the physical lens whose native baseline is the closest one not greater than the requested global zoom. */
    static LensOption chooseAutoPhysical(CameraManager cm, String logicalId, float globalZoom, int width, int height) {
        List<LensOption> lenses = physicalLenses(cm, logicalId);
        List<LensOption> usable = new ArrayList<>();
        for (LensOption o : lenses) if (supportsResolution(cm, o, width, height)) usable.add(o);
        if (usable.isEmpty()) usable = lenses;
        if (usable.isEmpty()) return null;
        usable.sort(Comparator.comparingDouble(o -> o.baseZoom));
        LensOption best = usable.get(0);
        for (LensOption o : usable) {
            if (o.baseZoom <= globalZoom + 0.001f) best = o;
            else break;
        }
        return best;
    }

    static boolean supportsResolution(CameraManager cm, LensOption option, int width, int height) {
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) return false;
            return contains(map.getOutputSizes(MediaCodec.class), width, height)
                    || contains(map.getOutputSizes(MediaRecorder.class), width, height)
                    || contains(map.getOutputSizes(android.graphics.SurfaceTexture.class), width, height);
        } catch (Exception ignored) { return false; }
    }

    private static boolean contains(Size[] sizes, int w, int h) {
        if (sizes == null) return false;
        for (Size s : sizes) if (s.getWidth() == w && s.getHeight() == h) return true;
        return false;
    }

    /** Only expose the requested webcam/video modes: 720p, 1080p, 1440p and 4K. */
    static List<Size> resolutions(CameraManager cm, LensOption option) {
        final int[][] wanted = new int[][]{{1280,720},{1920,1080},{2560,1440},{3840,2160}};
        List<Size> out = new ArrayList<>();
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                for (int[] wh : wanted) {
                    boolean ok = contains(map.getOutputSizes(MediaCodec.class), wh[0], wh[1])
                            || contains(map.getOutputSizes(MediaRecorder.class), wh[0], wh[1])
                            || contains(map.getOutputSizes(android.graphics.SurfaceTexture.class), wh[0], wh[1]);
                    if (ok) out.add(new Size(wh[0], wh[1]));
                }
            }
        } catch (Exception ignored) { }
        if (out.isEmpty()) out.add(new Size(1920, 1080));
        return out;
    }

    /** Keep 30/60, then add only >60 modes that the selected pipeline actually advertises. */
    static List<Integer> fpsOptions(CameraManager cm, LensOption option, Size resolution) {
        TreeSet<Integer> values = new TreeSet<>();
        values.add(30);
        values.add(60);
        try {
            CameraCharacteristics source = option.physicalId == null
                    ? cm.getCameraCharacteristics(option.openId)
                    : selectedCharacteristics(cm, option);
            Range<Integer>[] ranges = source.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    int upper = r.getUpper();
                    if (upper > 60 && upper <= 240) values.add(upper);
                }
            }

            // Constrained high-speed sessions are a logical-camera path in this app.
            if (option.physicalId == null && resolution != null) {
                CameraCharacteristics logical = cm.getCameraCharacteristics(option.openId);
                StreamConfigurationMap map = logical.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map != null) {
                    try {
                        Range<Integer>[] hs = map.getHighSpeedVideoFpsRangesFor(resolution);
                        if (hs != null) {
                            for (Range<Integer> r : hs) {
                                int upper = r.getUpper();
                                if (upper > 60 && upper <= 240) values.add(upper);
                            }
                        }
                    } catch (IllegalArgumentException ignored) { }
                }
            }
        } catch (Exception ignored) { }
        return new ArrayList<>(values);
    }

    static List<Integer> fpsOptions(CameraManager cm, LensOption option) {
        return fpsOptions(cm, option, new Size(1920, 1080));
    }

    static String resolutionLabel(Size s) {
        int w = s.getWidth(), h = s.getHeight();
        String name = "";
        if (w == 3840 && h == 2160) name = "4K UHD · ";
        else if (w == 2560 && h == 1440) name = "2K / 1440p · ";
        else if (w == 1920 && h == 1080) name = "1080p · ";
        else if (w == 1280 && h == 720) name = "720p · ";
        return name + w + "×" + h;
    }

    static float defaultZoomForSelection(CameraManager cm, String selection) {
        LensOption o = resolve(cm, selection);
        return o.physicalId == null ? 1f : Math.max(0.1f, o.baseZoom);
    }

    private static boolean isLogical(CameraCharacteristics c) {
        int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps == null) return false;
        for (int x : caps) if (x == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) return true;
        return false;
    }

    private static int facing(CameraCharacteristics c) {
        Integer f = c.get(CameraCharacteristics.LENS_FACING);
        return f == null ? CameraCharacteristics.LENS_FACING_EXTERNAL : f;
    }

    private static String faceName(int facing) {
        if (facing == CameraCharacteristics.LENS_FACING_BACK) return "Rear";
        if (facing == CameraCharacteristics.LENS_FACING_FRONT) return "Front";
        return "External";
    }

    private static String directLabel(String id, CameraCharacteristics c) {
        String face = faceName(facing(c));
        float eq = equivalentFocalMm(c);
        String eqText = Float.isNaN(eq) ? "" : String.format(Locale.US, " · ≈%.0f mm eq", eq);
        return face + " camera · ID " + id + eqText;
    }

    private static final class PhysicalInfo {
        final String id;
        final CameraCharacteristics c;
        final float eqMm;
        PhysicalInfo(String id, CameraCharacteristics c, float eqMm) { this.id = id; this.c = c; this.eqMm = eqMm; }
    }

    private static float choosePrimaryEquivalent(List<PhysicalInfo> infos) {
        float best = Float.NaN;
        float bestDistance = Float.MAX_VALUE;
        for (PhysicalInfo i : infos) {
            if (Float.isNaN(i.eqMm)) continue;
            float d = Math.abs(i.eqMm - 24f);
            if (d < bestDistance) { bestDistance = d; best = i.eqMm; }
        }
        return Float.isNaN(best) ? 24f : best;
    }

    private static float physicalBaseZoom(int facing, PhysicalInfo info, float primaryEq) {
        if (facing != CameraCharacteristics.LENS_FACING_BACK || Float.isNaN(info.eqMm)) return 1f;
        float raw = Math.max(0.1f, info.eqMm / Math.max(1f, primaryEq));
        // Friendly optical baselines. In particular, modern Samsung flagships are marketed as
        // 0.6x / 1x / 3x / 10x even though metadata focal-length ratios are not exactly those numbers.
        if (raw < 0.80f) return 0.6f;
        if (raw < 1.55f) return 1f;
        if (raw < 6.0f) return 3f;
        if (raw >= 6.0f) return 10f;
        return raw;
    }

    private static String physicalLabel(int facing, PhysicalInfo info, float primaryEq, float base) {
        String face = faceName(facing);
        if (Float.isNaN(info.eqMm)) return face + " lens · physical ID " + info.id;
        if (facing != CameraCharacteristics.LENS_FACING_BACK) {
            return String.format(Locale.US, "%s lens · ≈%.0f mm eq · physical ID %s", face, info.eqMm, info.id);
        }
        String kind = base < 0.8f ? "ultrawide" : base < 1.5f ? "wide" : "telephoto";
        return String.format(Locale.US, "Rear %s× %s · ≈%.0f mm eq · physical ID %s", zoomText(base), kind, info.eqMm, info.id);
    }

    private static String zoomText(float v) {
        if (Math.abs(v - Math.round(v)) < 0.01f) return Integer.toString(Math.round(v));
        return String.format(Locale.US, "%.1f", v);
    }

    private static float equivalentFocalMm(CameraCharacteristics c) {
        try {
            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            SizeF sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (focal == null || focal.length == 0 || sensor == null) return Float.NaN;
            double sensorDiag = Math.hypot(sensor.getWidth(), sensor.getHeight());
            if (sensorDiag <= 0) return Float.NaN;
            return (float)(focal[0] * 43.2666153 / sensorDiag);
        } catch (Exception ignored) { return Float.NaN; }
    }
}
