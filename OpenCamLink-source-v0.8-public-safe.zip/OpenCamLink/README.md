# OpenCam Link v0.8.0

Android Camera2 H.264 streamer with live phone preview and an OBS Studio browser-dock controller.

## v0.8 fixes

- Zoom now uses one global zoom scale across rear lenses.
  - 0.6x ultrawide baseline
  - 1x wide baseline
  - 3x telephoto baseline
  - 10x telephoto baseline when Camera2 exposes it
- Rear Auto mode actively changes the physical Camera2 output at those optical baselines instead of relying only on the OEM HAL to switch lenses.
- Manual physical lenses keep their optical baseline: selecting the 3x lens starts at 3x, not 1x.
- API 30+ uses `CONTROL_ZOOM_RATIO` in logical-camera/global coordinates even for pinned physical streams. This avoids the old double-crop behavior where increasing zoom on a tele lens could appear to zoom out and then in again.
- A consistent 16:9 sensor crop is requested for 720p, 1080p, 1440p and 4K so resolution changes no longer intentionally alter field of view.
- Resolution changes no longer reset zoom.
- OBS dock shows the currently active physical lens and effective requested zoom.
- Auto white balance now exposes an approximate Kelvin readout in the OBS dock. Camera2 does not report CCT/Kelvin directly, so this is explicitly shown as an estimate derived from AWB gains.
- 30/60 FPS remain available; higher FPS modes are added only when the selected Camera2 pipeline advertises them.
- Existing live controls, battery display, torch, bitrate slider, manual shutter slider and manual Kelvin control remain.

## OBS dock

Use the same dock URL as before:

- Wi-Fi: `http://PHONE_IP:4747/control`
- USB/ADB: `http://127.0.0.1:4747/control`

## Notes

Physical-lens and high-resolution support depends on what the phone OEM exposes through Camera2. If an OEM rejects an Auto physical stream at a requested resolution, v0.8 falls back to the logical rear camera rather than leaving the stream dead.
