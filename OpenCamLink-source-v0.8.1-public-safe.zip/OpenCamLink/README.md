# OpenCam Link v0.8.1

This revision keeps the v0.8 controls/features but restores the camera/zoom behavior from the early builds.

- Camera selector lists Android Camera2 public camera IDs directly (rear/front cameras as the OEM exposes them).
- No automatic physical-lens switching.
- Zoom is the original centered digital `SCALER_CROP_REGION` on the selected camera, from 1x to that camera's reported maximum digital zoom.
- 720p, 1080p, 2K/1440p and 4K resolution choices remain.
- 30/60 FPS remain, with supported >60 FPS modes added when Camera2 reports them.
- Live bitrate, exposure, shutter slider, manual WB, focus, stabilization, torch, battery and OBS dock remain.
- Removed the inaccurate Auto-WB Kelvin estimate from the phone/OBS state and dock.

Build with the existing GitHub Actions workflow by extracting this ZIP's `OpenCamLink` directory and running `gradle --no-daemon :app:assembleDebug`.
