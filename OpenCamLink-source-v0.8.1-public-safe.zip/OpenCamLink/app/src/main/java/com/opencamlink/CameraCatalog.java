package com.opencamlink;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.util.Range;
import android.util.Size;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Camera discovery intentionally mirrors the early OpenCam Link behavior:
 * every public Camera2 camera ID is listed directly and zoom is digital crop
 * on that selected camera. No physical-lens auto switching is performed here.
 */
final class CameraCatalog {
    static final class LensOption {
        final String selection;
        final String label;
        final String openId;
        final String physicalId;
        final int facing;
        final float baseZoom;

        LensOption(String selection, String label, String openId, String physicalId, int facing, float baseZoom) {
            this.selection = selection;
            this.label = label;
            this.openId = openId;
            this.physicalId = physicalId;
            this.facing = facing;
            this.baseZoom = baseZoom;
        }
    }

    private CameraCatalog() { }

    static List<LensOption> list(CameraManager cm) {
        List<LensOption> out = new ArrayList<>();
        try {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                out.add(new LensOption(id, directLabel(id, c), id, null, facing(c), 1f));
            }
        } catch (Exception ignored) { }
        if (out.isEmpty()) {
            out.add(new LensOption("0", "Camera ID 0", "0", null,
                    CameraCharacteristics.LENS_FACING_EXTERNAL, 1f));
        }
        return out;
    }

    static String defaultSelection(CameraManager cm) {
        List<LensOption> options = list(cm);
        return options.isEmpty() ? "0" : options.get(0).selection;
    }

    static LensOption resolve(CameraManager cm, String selection) {
        List<LensOption> options = list(cm);
        if (selection != null) {
            for (LensOption o : options) {
                if (selection.equals(o.selection) || selection.equals(o.openId)) return o;
            }
            // Migrate selections written by the experimental physical-lens builds.
            if (selection.startsWith("cam:")) {
                String id = selection.substring(4);
                for (LensOption o : options) if (id.equals(o.openId)) return o;
            }
            if (selection.startsWith("auto:")) {
                String id = selection.substring(5);
                for (LensOption o : options) if (id.equals(o.openId)) return o;
            }
            if (selection.startsWith("phys:")) {
                String[] parts = selection.split(":");
                if (parts.length >= 2) {
                    String logicalId = parts[1];
                    for (LensOption o : options) if (logicalId.equals(o.openId)) return o;
                }
            }
        }
        return options.get(0);
    }

    static CameraCharacteristics selectedCharacteristics(CameraManager cm, LensOption option) throws Exception {
        return cm.getCameraCharacteristics(option.openId);
    }

    // Kept for source compatibility with the controller. The restored camera model never uses them.
    static List<LensOption> physicalLenses(CameraManager cm, String logicalId) { return new ArrayList<>(); }
    static LensOption chooseAutoPhysical(CameraManager cm, String logicalId, float globalZoom, int width, int height) { return null; }

    static boolean supportsResolution(CameraManager cm, LensOption option, int width, int height) {
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) return false;
            return contains(map.getOutputSizes(MediaCodec.class), width, height)
                    || contains(map.getOutputSizes(MediaRecorder.class), width, height)
                    || contains(map.getOutputSizes(android.graphics.SurfaceTexture.class), width, height);
        } catch (Exception ignored) { return false; }
    }

    private static boolean contains(Size[] sizes, int w, int h) {
        if (sizes == null) return false;
        for (Size s : sizes) if (s.getWidth() == w && s.getHeight() == h) return true;
        return false;
    }

    /** Only expose the requested webcam/video modes: 720p, 1080p, 1440p and 4K. */
    static List<Size> resolutions(CameraManager cm, LensOption option) {
        final int[][] wanted = new int[][]{{1280,720},{1920,1080},{2560,1440},{3840,2160}};
        List<Size> out = new ArrayList<>();
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                for (int[] wh : wanted) {
                    boolean ok = contains(map.getOutputSizes(MediaCodec.class), wh[0], wh[1])
                            || contains(map.getOutputSizes(MediaRecorder.class), wh[0], wh[1])
                            || contains(map.getOutputSizes(android.graphics.SurfaceTexture.class), wh[0], wh[1]);
                    if (ok) out.add(new Size(wh[0], wh[1]));
                }
            }
        } catch (Exception ignored) { }
        if (out.isEmpty()) out.add(new Size(1920, 1080));
        return out;
    }

    /** Keep 30/60, then add >60 modes when the selected public camera reports them. */
    static List<Integer> fpsOptions(CameraManager cm, LensOption option, Size resolution) {
        TreeSet<Integer> values = new TreeSet<>();
        values.add(30);
        values.add(60);
        try {
            CameraCharacteristics c = selectedCharacteristics(cm, option);
            Range<Integer>[] ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    int upper = r.getUpper();
                    if (upper > 60 && upper <= 240) values.add(upper);
                }
            }
            if (resolution != null) {
                StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map != null) {
                    try {
                        Range<Integer>[] hs = map.getHighSpeedVideoFpsRangesFor(resolution);
                        if (hs != null) {
                            for (Range<Integer> r : hs) {
                                int upper = r.getUpper();
                                if (upper > 60 && upper <= 240) values.add(upper);
                            }
                        }
                    } catch (IllegalArgumentException ignored) { }
                }
            }
        } catch (Exception ignored) { }
        return new ArrayList<>(values);
    }

    static List<Integer> fpsOptions(CameraManager cm, LensOption option) {
        return fpsOptions(cm, option, new Size(1920, 1080));
    }

    static String resolutionLabel(Size s) {
        int w = s.getWidth(), h = s.getHeight();
        String name = "";
        if (w == 3840 && h == 2160) name = "4K UHD · ";
        else if (w == 2560 && h == 1440) name = "2K / 1440p · ";
        else if (w == 1920 && h == 1080) name = "1080p · ";
        else if (w == 1280 && h == 720) name = "720p · ";
        return name + w + "×" + h;
    }

    static float defaultZoomForSelection(CameraManager cm, String selection) { return 1f; }

    private static int facing(CameraCharacteristics c) {
        Integer f = c.get(CameraCharacteristics.LENS_FACING);
        return f == null ? CameraCharacteristics.LENS_FACING_EXTERNAL : f;
    }

    private static String faceName(int facing) {
        if (facing == CameraCharacteristics.LENS_FACING_BACK) return "Rear";
        if (facing == CameraCharacteristics.LENS_FACING_FRONT) return "Front";
        return "External";
    }

    private static String directLabel(String id, CameraCharacteristics c) {
        String face = faceName(facing(c));
        try {
            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            if (focal != null && focal.length > 0)
                return String.format(Locale.US, "%s — ID %s — %.1f mm", face, id, focal[0]);
        } catch (Exception ignored) { }
        return face + " — ID " + id;
    }
}
