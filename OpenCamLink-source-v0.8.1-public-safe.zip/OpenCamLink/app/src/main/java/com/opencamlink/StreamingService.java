package com.opencamlink;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.BatteryManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Range;
import android.util.Size;
import android.util.Log;
import android.view.Surface;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class StreamingService extends Service {
    public static final String ACTION_START = "com.opencamlink.START";
    public static final String ACTION_RESTART = "com.opencamlink.RESTART";
    public static final String ACTION_STOP = "com.opencamlink.STOP";
    public static final String ACTION_UPDATE = "com.opencamlink.UPDATE";

    private static final String TAG = "OpenCamLink.Service";
    private static final String CHANNEL = "streaming";

    private final VideoBroadcaster broadcaster = new VideoBroadcaster();
    private final LocalBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private CameraController camera;
    private CompatServer server;
    private NsdAdvertiser nsd;
    private Surface previewSurface;
    private volatile boolean running;

    public final class LocalBinder extends Binder {
        public StreamingService getService() { return StreamingService.this; }
    }

    @Override public void onCreate() { super.onCreate(); createNotificationChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopEverything(true); stopSelf(); return START_NOT_STICKY;
        }
        if (ACTION_UPDATE.equals(action)) { applySettingsLive(); return START_STICKY; }

        startForeground(47, buildNotification());
        if (ACTION_RESTART.equals(action)) {
            stopEverything(false); startEverything(); return START_STICKY;
        }
        if (!running) startEverything();
        return START_STICKY;
    }

    public boolean isRunning() { return running; }

    public void setPreviewSurface(Surface surface) {
        previewSurface = surface;
        if (camera != null) camera.setPreviewSurface(surface);
    }

    public void clearPreviewSurface(Surface surface) {
        if (previewSurface == surface) {
            previewSurface = null;
            if (camera != null) camera.setPreviewSurface(null);
        }
    }

    private void startEverything() {
        try {
            SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
            int port = p.getInt("port", 4747);
            int fps = p.getInt("fps", 60);
            int bitrate = clamp(p.getInt("bitrate", 20_000_000), 1_000_000, 80_000_000);
            int width = p.getInt("width", 1920);
            int height = p.getInt("height", 1080);
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            String selection = p.getString("camera_id", null);
            if (selection == null) {
                selection = CameraCatalog.defaultSelection(cm);
                p.edit().putString("camera_id", selection).apply();
            }
            CameraCatalog.LensOption startLens = CameraCatalog.resolve(cm, selection);
            float savedZoom = Math.max(1f, p.getFloat("zoom", CameraCatalog.defaultZoomForSelection(cm, selection)));
            if (savedZoom != p.getFloat("zoom", 1f)) p.edit().putFloat("zoom", savedZoom).apply();

            camera = new CameraController(this, broadcaster);
            camera.configure(selection, width, height, fps, bitrate);
            camera.setPreviewSurface(previewSurface);
            camera.start();
            applySettingsLive();

            server = new CompatServer(port, broadcaster, this);
            server.start();
            nsd = new NsdAdvertiser(this);
            nsd.start(port);
            running = true;
            Log.i(TAG, "streaming/control server started on port " + port + " at " + width + "x" + height + " @ " + fps);
        } catch (Exception e) {
            Log.e(TAG, "failed to start", e);
            stopEverything(true);
            stopSelf();
        }
    }

    public void applySettingsLive() {
        if (camera == null) return;
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        boolean manualExposure = p.getBoolean("manual_exposure", false);
        int iso = p.getInt("iso", 200);
        long exposureNs = p.getLong("exposure_ns", 8_333_333L);
        int aeComp = p.getInt("ae_comp", 0);
        int awb = p.getInt("awb", CaptureRequest.CONTROL_AWB_MODE_AUTO);
        boolean manualWb = p.getBoolean("manual_wb", false);
        int wbKelvin = p.getInt("wb_kelvin", 5000);
        boolean manualFocus = p.getBoolean("manual_focus", false);
        float focusDistance = p.getFloat("focus_distance", 0f);
        float zoom = p.getFloat("zoom", 1f);
        int antibanding = p.getInt("antibanding", CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO);
        boolean ois = p.getBoolean("ois", true);
        boolean eis = p.getBoolean("eis", false);
        boolean torch = p.getBoolean("torch", false);
        int bitrate = clamp(p.getInt("bitrate", 20_000_000), 1_000_000, 80_000_000);
        camera.updateControls(manualExposure, iso, exposureNs, aeComp, awb, manualWb, wbKelvin,
                manualFocus, focusDistance, zoom, antibanding, ois, eis, torch, bitrate);
    }

    /** Called by the built-in OBS browser dock API. */
    void applyControlValues(Map<String, String> values) {
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit();
        String requestedCamera = null;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            String k = entry.getKey(), v = entry.getValue();
            try {
                switch (k) {
                    case "manual_exposure": e.putBoolean(k, bool(v)); break;
                    case "iso": e.putInt(k, Integer.parseInt(v)); break;
                    case "exposure_ms": e.putLong("exposure_ns", (long)(Double.parseDouble(v) * 1_000_000.0)); break;
                    case "exposure_ns": e.putLong(k, Long.parseLong(v)); break;
                    case "ae_comp": e.putInt(k, Integer.parseInt(v)); break;
                    case "awb": e.putInt(k, Integer.parseInt(v)); break;
                    case "manual_wb": e.putBoolean(k, bool(v)); break;
                    case "wb_kelvin": e.putInt(k, clamp(Integer.parseInt(v), 1800, 12000)); break;
                    case "manual_focus": e.putBoolean(k, bool(v)); break;
                    case "focus_distance": e.putFloat(k, Float.parseFloat(v)); break;
                    case "zoom": e.putFloat(k, Float.parseFloat(v)); break;
                    case "antibanding": e.putInt(k, Integer.parseInt(v)); break;
                    case "ois": e.putBoolean(k, bool(v)); break;
                    case "eis": e.putBoolean(k, bool(v)); break;
                    case "torch": e.putBoolean(k, bool(v)); break;
                    case "show_battery": e.putBoolean(k, bool(v)); break;
                    case "bitrate": e.putInt(k, clamp(Integer.parseInt(v), 1_000_000, 80_000_000)); break;
                    case "camera_id": e.putString(k, v); requestedCamera = v; break;
                    case "fps": e.putInt(k, Integer.parseInt(v)); break;
                    case "width": e.putInt(k, Integer.parseInt(v)); break;
                    case "height": e.putInt(k, Integer.parseInt(v)); break;
                }
            } catch (Exception ignored) { }
        }
        e.apply();
        applySettingsLive();
    }

    void restartFromControlAsync() {
        mainHandler.postDelayed(() -> {
            if (!running) return;
            stopEverything(false);
            startEverything();
        }, 350);
    }

    String controlStateJson() {
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        String selection = p.getString("camera_id", null);
        if (selection == null) selection = CameraCatalog.defaultSelection(cm);
        CameraCatalog.LensOption selected = CameraCatalog.resolve(cm, selection);

        int fps = p.getInt("fps", 60);
        int width = p.getInt("width", 1920);
        int height = p.getInt("height", 1080);
        int bitrate = clamp(p.getInt("bitrate", 20_000_000), 1_000_000, 80_000_000);

        float minZoom = 1f, maxZoom = 10f, maxFocus = 10f;
        int isoMin = 50, isoMax = 3200;
        long exposureMin = 100_000L, exposureMax = 1_000_000_000L;
        int aeMin = -6, aeMax = 6;
        boolean flashAvailable = false;
        try {
            CameraCharacteristics c = CameraCatalog.selectedCharacteristics(cm, selected);
            minZoom = 1f;
            Float mz = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (mz != null && mz > 1f) maxZoom = mz;
            Float mf = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
            Range<Integer> ir = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            Range<Long> er = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            Range<Integer> ar = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (mf != null && mf > 0f) maxFocus = mf;
            if (ir != null) { isoMin = ir.getLower(); isoMax = ir.getUpper(); }
            if (er != null) { exposureMin = er.getLower(); exposureMax = er.getUpper(); }
            if (ar != null) { aeMin = ar.getLower(); aeMax = ar.getUpper(); }
            Boolean fa = cm.getCameraCharacteristics(selected.openId).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            flashAvailable = Boolean.TRUE.equals(fa);
        } catch (Exception ignored) { }

        StringBuilder camerasJson = new StringBuilder("[");
        List<CameraCatalog.LensOption> cameras = CameraCatalog.list(cm);
        for (int i = 0; i < cameras.size(); i++) {
            CameraCatalog.LensOption o = cameras.get(i);
            if (i > 0) camerasJson.append(',');
            camerasJson.append("{\"id\":\"").append(json(o.selection)).append("\",\"label\":\"")
                    .append(json(o.label)).append("\"}");
        }
        camerasJson.append(']');

        StringBuilder resJson = new StringBuilder("[");
        List<Size> resolutions = CameraCatalog.resolutions(cm, selected);
        for (int i = 0; i < resolutions.size(); i++) {
            Size s = resolutions.get(i);
            if (i > 0) resJson.append(',');
            resJson.append("{\"w\":").append(s.getWidth()).append(",\"h\":").append(s.getHeight())
                    .append(",\"label\":\"").append(json(CameraCatalog.resolutionLabel(s))).append("\"}");
        }
        resJson.append(']');

        StringBuilder fpsJson = new StringBuilder("[");
        List<Integer> fpsOptions = CameraCatalog.fpsOptions(cm, selected, new Size(width, height));
        for (int i = 0; i < fpsOptions.size(); i++) {
            if (i > 0) fpsJson.append(',');
            fpsJson.append(fpsOptions.get(i));
        }
        fpsJson.append(']');

        int battery = batteryPercent();
        boolean charging = isCharging();
        long frameLimitNs = (long)(1_000_000_000L / Math.max(1, fps));
        long usableExposureMax = Math.min(exposureMax, frameLimitNs);
        String activeLens = camera == null ? selected.label : camera.getActiveLensLabel();
        float effectiveZoom = camera == null ? p.getFloat("zoom", 1f) : camera.getEffectiveZoom();

        return "{" +
                "\"version\":\"0.8.1\"," +
                "\"running\":" + running + ',' +
                "\"camera_id\":\"" + json(selected.selection) + "\"," +
                "\"width\":" + width + ',' +
                "\"height\":" + height + ',' +
                "\"fps\":" + fps + ',' +
                "\"bitrate\":" + bitrate + ',' +
                "\"bitrate_min\":1000000,\"bitrate_max\":80000000," +
                "\"manual_exposure\":" + p.getBoolean("manual_exposure", false) + ',' +
                "\"iso\":" + p.getInt("iso", 200) + ',' +
                "\"exposure_ns\":" + p.getLong("exposure_ns", 8_333_333L) + ',' +
                "\"ae_comp\":" + p.getInt("ae_comp", 0) + ',' +
                "\"awb\":" + p.getInt("awb", CaptureRequest.CONTROL_AWB_MODE_AUTO) + ',' +
                "\"manual_wb\":" + p.getBoolean("manual_wb", false) + ',' +
                "\"wb_kelvin\":" + p.getInt("wb_kelvin", 5000) + ',' +
                "\"manual_focus\":" + p.getBoolean("manual_focus", false) + ',' +
                "\"focus_distance\":" + fmt(p.getFloat("focus_distance", 0f)) + ',' +
                "\"zoom\":" + fmt(p.getFloat("zoom", 1f)) + ',' +
                "\"effective_zoom\":" + fmt(effectiveZoom) + ',' +
                "\"active_lens\":\"" + json(activeLens) + "\"," +
                "\"antibanding\":" + p.getInt("antibanding", CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO) + ',' +
                "\"ois\":" + p.getBoolean("ois", true) + ',' +
                "\"eis\":" + p.getBoolean("eis", false) + ',' +
                "\"torch\":" + p.getBoolean("torch", false) + ',' +
                "\"flash_available\":" + flashAvailable + ',' +
                "\"show_battery\":" + p.getBoolean("show_battery", true) + ',' +
                "\"battery\":" + battery + ',' +
                "\"charging\":" + charging + ',' +
                "\"min_zoom\":" + fmt(minZoom) + ',' +
                "\"max_zoom\":" + fmt(maxZoom) + ',' +
                "\"max_focus\":" + fmt(maxFocus) + ',' +
                "\"iso_min\":" + isoMin + ',' +
                "\"iso_max\":" + isoMax + ',' +
                "\"exposure_min_ns\":" + exposureMin + ',' +
                "\"exposure_max_ns\":" + usableExposureMax + ',' +
                "\"ae_min\":" + aeMin + ',' +
                "\"ae_max\":" + aeMax + ',' +
                "\"wb_kelvin_min\":1800,\"wb_kelvin_max\":12000," +
                "\"cameras\":" + camerasJson + ',' +
                "\"resolutions\":" + resJson + ',' +
                "\"fps_options\":" + fpsJson +
                "}";
    }

    private int batteryPercent() {
        try {
            BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
            int p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            return p < 0 ? 0 : Math.min(100, p);
        } catch (Exception ignored) { return 0; }
    }

    private boolean isCharging() {
        try {
            Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return false;
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        } catch (Exception ignored) { return false; }
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(v, hi)); }
    private static boolean bool(String v) { return "1".equals(v) || "true".equalsIgnoreCase(v) || "on".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v); }
    private static String fmt(float v) { return String.format(Locale.US, "%.4f", v); }
    private static String json(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private void stopEverything(boolean removeForeground) {
        running = false;
        if (nsd != null) { nsd.stop(); nsd = null; }
        if (server != null) { server.stop(); server = null; }
        if (camera != null) { camera.stop(); camera = null; }
        broadcaster.closeAll();
        if (removeForeground) { try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { } }
    }

    @Override public void onDestroy() { stopEverything(true); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return binder; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Camera streaming", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        return b.setContentTitle("OpenCam Link")
                .setContentText(p.getInt("width", 1920) + "×" + p.getInt("height", 1080) + " camera + OBS controls")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();
    }
}
