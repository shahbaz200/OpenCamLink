# OpenCam Link v0.4

Independent Android Camera2 -> H.264 sender compatible with the public network interface used by the DroidCam OBS receiver plugin.

## v0.4 improvements

- Local live preview on the phone while the streaming camera is active.
- ISO, shutter, AE compensation, white-balance preset, manual focus, zoom, anti-flicker, OIS and EIS update live without stopping the server.
- Bitrate updates live through MediaCodec parameters.
- Camera and target FPS are clearly marked as restart-required settings.
- START / RESTART button applies pipeline-level changes without reinstalling the app.
- Camera characteristics are used to clamp ISO, exposure, AE compensation, focus distance and zoom more safely.
- Preview uses a lower-resolution local Camera2 output so the network stream remains 1920x1080.
- Wi-Fi and USB/ADB compatibility remain on port 4747.

Audio is still intentionally disabled in this build.

This is an independent implementation. It contains no DroidCam branding, assets, Android application code, licensing logic or entitlement bypass.
