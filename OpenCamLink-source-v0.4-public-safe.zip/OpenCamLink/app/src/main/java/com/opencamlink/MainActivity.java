package com.opencamlink;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private final List<String> cameraIds = new ArrayList<>();
    private final List<String> cameraLabels = new ArrayList<>();

    private Spinner cameraSpinner, fpsSpinner, bitrateSpinner, awbSpinner, antiSpinner;
    private CheckBox manualExposure, manualFocus, ois, eis;
    private SeekBar isoBar, shutterBar, aeBar, focusBar, zoomBar;
    private TextView isoText, shutterText, aeText, focusText, zoomText, statusText;
    private TextureView previewView;
    private Surface previewSurface;

    private StreamingService service;
    private boolean bound;
    private boolean initializing = true;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((StreamingService.LocalBinder) binder).getService();
            bound = true;
            attachPreviewIfReady();
            refreshStatus();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            bound = false;
            service = null;
            refreshStatus();
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        requestPermissionsIfNeeded();
        buildUi();
        initializing = false;
    }

    @Override protected void onStart() {
        super.onStart();
        bindService(new Intent(this, StreamingService.class), connection, Context.BIND_AUTO_CREATE);
    }

    @Override protected void onStop() {
        if (bound) {
            try { if (service != null && previewSurface != null) service.clearPreviewSurface(previewSurface); } catch (Exception ignored) {}
            try { unbindService(connection); } catch (Exception ignored) {}
            bound = false;
            service = null;
        }
        super.onStop();
    }

    private void requestPermissionsIfNeeded() {
        List<String> req = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) req.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            req.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), 100);
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(16);
        v.setPadding(0, 16, 0, 6);
        root.addView(v);
        return v;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 40);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("OpenCam Link v0.4");
        title.setTextSize(28);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("1080p H.264 camera streamer with live preview and live Camera2 controls. No watermark.");
        root.addView(sub);

        statusText = label("Status: waiting for service");
        label("Network addresses: " + localIpv4() + "   |   port 4747\nUSB: use OBS plugin USB mode (ADB forwarding)");

        label("Live preview (appears while the stream camera is active)");
        previewView = new TextureView(this);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int previewH = Math.min((screenW * 9) / 16, dp(280));
        previewView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(dp(180), previewH)));
        previewView.setOpaque(false);
        previewView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
                configurePreviewBuffer(st);
                previewSurface = new Surface(st);
                attachPreviewIfReady();
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                if (service != null && previewSurface != null) service.clearPreviewSurface(previewSurface);
                if (previewSurface != null) previewSurface.release();
                previewSurface = null;
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        root.addView(previewView);

        loadCameras();
        label("Camera (restart stream to apply)");
        cameraSpinner = spinner(cameraLabels);
        String savedCam = prefs.getString("camera_id", null);
        if (savedCam != null && cameraIds.contains(savedCam)) cameraSpinner.setSelection(cameraIds.indexOf(savedCam));

        label("Frame rate (restart stream to apply)");
        fpsSpinner = spinner(Arrays.asList("30 FPS", "60 FPS"));
        fpsSpinner.setSelection(prefs.getInt("fps", 60) == 60 ? 1 : 0);

        label("Bitrate (LIVE)");
        bitrateSpinner = spinner(Arrays.asList("8 Mbps", "12 Mbps", "16 Mbps", "20 Mbps", "24 Mbps", "32 Mbps"));
        int[] bitrates = {8, 12, 16, 20, 24, 32};
        int savedB = prefs.getInt("bitrate", 20_000_000) / 1_000_000;
        int bi = 3;
        for (int i = 0; i < bitrates.length; i++) if (bitrates[i] == savedB) bi = i;
        bitrateSpinner.setSelection(bi);

        manualExposure = check("Manual exposure (LIVE)", prefs.getBoolean("manual_exposure", false));
        isoText = label("");
        isoBar = seek(50, 3200, prefs.getInt("iso", 200), v -> {
            prefs.edit().putInt("iso", v).apply();
            isoText.setText("ISO: " + v + " (LIVE)");
            applyLive();
        });
        isoText.setText("ISO: " + prefs.getInt("iso", 200) + " (LIVE)");

        shutterText = label("");
        shutterBar = seek(1, 100, shutterMsToProgress(prefs.getLong("exposure_ns", 8_333_333L)), v -> {
            double ms = progressToShutterMs(v);
            prefs.edit().putLong("exposure_ns", (long) (ms * 1_000_000)).apply();
            shutterText.setText(String.format(Locale.US, "Shutter: %.2f ms (≈1/%.0f) (LIVE)", ms, 1000.0 / ms));
            applyLive();
        });
        updateShutterLabel();

        aeText = label("");
        aeBar = seek(-6, 6, prefs.getInt("ae_comp", 0), v -> {
            prefs.edit().putInt("ae_comp", v).apply();
            aeText.setText("Auto exposure compensation: " + v + " (LIVE)");
            applyLive();
        });
        aeText.setText("Auto exposure compensation: " + prefs.getInt("ae_comp", 0) + " (LIVE)");

        label("White balance (LIVE)");
        awbSpinner = spinner(Arrays.asList("Auto", "Incandescent", "Fluorescent", "Warm fluorescent", "Daylight", "Cloudy daylight", "Shade"));
        int[] awbs = awbModes();
        int savedAwb = prefs.getInt("awb", awbs[0]);
        for (int i = 0; i < awbs.length; i++) if (awbs[i] == savedAwb) awbSpinner.setSelection(i);

        manualFocus = check("Manual focus (LIVE)", prefs.getBoolean("manual_focus", false));
        focusText = label("");
        focusBar = seek(0, 1000, (int) (prefs.getFloat("focus_distance", 0f) * 100), v -> {
            float d = v / 100f;
            prefs.edit().putFloat("focus_distance", d).apply();
            focusText.setText(String.format(Locale.US, "Focus distance: %.2f diopters (LIVE)", d));
            applyLive();
        });
        focusText.setText(String.format(Locale.US, "Focus distance: %.2f diopters (LIVE)", focusBar.getProgress() / 100f));

        zoomText = label("");
        zoomBar = seek(100, 1000, (int) (prefs.getFloat("zoom", 1f) * 100), v -> {
            float z = v / 100f;
            prefs.edit().putFloat("zoom", z).apply();
            zoomText.setText(String.format(Locale.US, "Zoom: %.2fx (LIVE)", z));
            applyLive();
        });
        zoomText.setText(String.format(Locale.US, "Zoom: %.2fx (LIVE)", zoomBar.getProgress() / 100f));

        label("Anti-flicker (LIVE)");
        antiSpinner = spinner(Arrays.asList("Auto", "Off", "50 Hz", "60 Hz"));
        int[] antis = antiModes();
        int savedAnti = prefs.getInt("antibanding", antis[0]);
        for (int i = 0; i < antis.length; i++) if (antis[i] == savedAnti) antiSpinner.setSelection(i);

        ois = check("Optical stabilization (OIS) (LIVE)", prefs.getBoolean("ois", true));
        eis = check("Electronic video stabilization (EIS) (LIVE)", prefs.getBoolean("eis", false));

        TextView liveNote = label("Most controls above update immediately while streaming. Camera and FPS change the capture pipeline, so use START / RESTART after changing those two.");
        liveNote.setTextSize(14);

        Button start = new Button(this);
        start.setText("START / RESTART 1080P STREAM");
        root.addView(start);
        start.setOnClickListener(v -> {
            saveSelections();
            Intent i = new Intent(this, StreamingService.class).setAction(StreamingService.ACTION_RESTART);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Starting / restarting stream on port 4747", Toast.LENGTH_SHORT).show();
            statusText.postDelayed(this::refreshStatus, 700);
        });

        Button stop = new Button(this);
        stop.setText("STOP STREAM SERVER");
        root.addView(stop);
        stop.setOnClickListener(v -> {
            startService(new Intent(this, StreamingService.class).setAction(StreamingService.ACTION_STOP));
            statusText.postDelayed(this::refreshStatus, 300);
        });

        TextView help = label("OBS setup");
        help.setText("1) Tap START / RESTART STREAM.\n2) OBS → Add Source → DroidCam OBS.\n3) Wi-Fi: use the phone's wlan/Wi-Fi address above, port 4747.\n4) Keep Enable Audio OFF for this build. Use AVC/H.264 and 1920×1080.\n5) USB: enable USB debugging, connect the phone, Refresh Device List and select it.\n\nThe preview is local to the phone and is not a second network stream. Live control changes update the active Camera2 repeating request without stopping the server.");

        manualExposure.setOnCheckedChangeListener((b1, c) -> {
            prefs.edit().putBoolean("manual_exposure", c).apply();
            applyLive();
        });
        manualFocus.setOnCheckedChangeListener((b1, c) -> {
            prefs.edit().putBoolean("manual_focus", c).apply();
            applyLive();
        });
        ois.setOnCheckedChangeListener((b1, c) -> {
            prefs.edit().putBoolean("ois", c).apply();
            applyLive();
        });
        eis.setOnCheckedChangeListener((b1, c) -> {
            prefs.edit().putBoolean("eis", c).apply();
            applyLive();
        });

        cameraSpinner.setOnItemSelectedListener(new SimpleItemSelected() {
            @Override public void selected(int position) {
                if (initializing || cameraIds.isEmpty()) return;
                prefs.edit().putString("camera_id", cameraIds.get(position)).apply();
                markRestartNeeded("Camera changed — restart stream to apply");
            }
        });
        fpsSpinner.setOnItemSelectedListener(new SimpleItemSelected() {
            @Override public void selected(int position) {
                if (initializing) return;
                prefs.edit().putInt("fps", position == 1 ? 60 : 30).apply();
                markRestartNeeded("FPS changed — restart stream to apply");
            }
        });
        bitrateSpinner.setOnItemSelectedListener(new SimpleItemSelected() {
            @Override public void selected(int position) {
                if (initializing) return;
                int[] bps = {8, 12, 16, 20, 24, 32};
                prefs.edit().putInt("bitrate", bps[position] * 1_000_000).apply();
                applyLive();
            }
        });
        awbSpinner.setOnItemSelectedListener(new SimpleItemSelected() {
            @Override public void selected(int position) {
                if (initializing) return;
                prefs.edit().putInt("awb", awbModes()[position]).apply();
                applyLive();
            }
        });
        antiSpinner.setOnItemSelectedListener(new SimpleItemSelected() {
            @Override public void selected(int position) {
                if (initializing) return;
                prefs.edit().putInt("antibanding", antiModes()[position]).apply();
                applyLive();
            }
        });

        setContentView(sv);
    }

    private abstract static class SimpleItemSelected implements AdapterView.OnItemSelectedListener {
        abstract void selected(int position);
        @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) { selected(position); }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    private void markRestartNeeded(String message) {
        if (service != null && service.isRunning()) statusText.setText("Status: STREAMING • " + message);
        else statusText.setText("Status: " + message);
    }

    private void saveSelections() {
        int[] bitrates = {8, 12, 16, 20, 24, 32};
        SharedPreferences.Editor e = prefs.edit();
        if (!cameraIds.isEmpty()) e.putString("camera_id", cameraIds.get(cameraSpinner.getSelectedItemPosition()));
        e.putInt("fps", fpsSpinner.getSelectedItemPosition() == 1 ? 60 : 30);
        e.putInt("bitrate", bitrates[bitrateSpinner.getSelectedItemPosition()] * 1_000_000);
        e.putInt("awb", awbModes()[awbSpinner.getSelectedItemPosition()]);
        e.putInt("antibanding", antiModes()[antiSpinner.getSelectedItemPosition()]);
        e.apply();
    }

    private void applyLive() {
        if (initializing) return;
        if (bound && service != null && service.isRunning()) {
            service.applySettingsLive();
            statusText.setText("Status: STREAMING • live setting applied");
        }
    }

    private void attachPreviewIfReady() {
        if (bound && service != null && previewSurface != null && previewSurface.isValid()) {
            service.setPreviewSurface(previewSurface);
        }
    }

    private void refreshStatus() {
        if (service != null && service.isRunning()) statusText.setText("Status: STREAMING • live controls active");
        else statusText.setText("Status: stopped");
    }

    private CheckBox check(String t, boolean c) {
        CheckBox x = new CheckBox(this);
        x.setText(t);
        x.setChecked(c);
        root.addView(x);
        return x;
    }

    private Spinner spinner(List<String> values) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        root.addView(s);
        return s;
    }

    interface SeekListener { void onValue(int value); }
    private SeekBar seek(int min, int max, int value, SeekListener l) {
        SeekBar s = new SeekBar(this);
        if (Build.VERSION.SDK_INT >= 26) {
            s.setMin(min); s.setMax(max); s.setProgress(value);
        } else {
            s.setMax(max - min); s.setProgress(value - min);
        }
        root.addView(s);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                if (fromUser) l.onValue(Build.VERSION.SDK_INT >= 26 ? p : p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { }
        });
        return s;
    }

    private void loadCameras() {
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Integer f = c.get(CameraCharacteristics.LENS_FACING);
                String face = f == null ? "Camera" : (f == CameraCharacteristics.LENS_FACING_FRONT ? "Front" : f == CameraCharacteristics.LENS_FACING_BACK ? "Rear" : "External");
                Float focal = null;
                float[] fl = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                if (fl != null && fl.length > 0) focal = fl[0];
                cameraIds.add(id);
                cameraLabels.add(face + " — ID " + id + (focal == null ? "" : String.format(Locale.US, " — %.1f mm", focal)));
            }
        } catch (Exception e) {
            cameraIds.add("0");
            cameraLabels.add("Camera ID 0");
        }
    }

    private void configurePreviewBuffer(SurfaceTexture st) {
        int w = 640, h = 360;
        try {
            String id = prefs.getString("camera_id", null);
            if (id == null && !cameraIds.isEmpty()) id = cameraIds.get(0);
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            if (id != null) {
                StreamConfigurationMap map = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map != null) {
                    Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
                    Size best = null;
                    if (sizes != null) {
                        for (Size s : sizes) {
                            float ratio = s.getWidth() / (float) s.getHeight();
                            if (Math.abs(ratio - 16f / 9f) > 0.08f) continue;
                            if (s.getWidth() > 1280) continue;
                            if (best == null || s.getWidth() > best.getWidth()) best = s;
                        }
                    }
                    if (best != null) { w = best.getWidth(); h = best.getHeight(); }
                }
            }
        } catch (Exception ignored) { }
        st.setDefaultBufferSize(w, h);
    }

    private String localIpv4() {
        try {
            List<String> wifi = new ArrayList<>();
            List<String> other = new ArrayList<>();
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a.isLoopbackAddress() || !(a instanceof Inet4Address)) continue;
                    String item = ni.getName() + "=" + a.getHostAddress();
                    String n = ni.getName().toLowerCase(Locale.US);
                    if (n.startsWith("wlan") || n.startsWith("wifi")) wifi.add(item); else other.add(item);
                }
            }
            wifi.addAll(other);
            return wifi.isEmpty() ? "phone-IP" : String.join("  |  ", wifi);
        } catch (Exception ignored) { }
        return "phone-IP";
    }

    private int[] awbModes() {
        return new int[]{CaptureRequest.CONTROL_AWB_MODE_AUTO, CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT, CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT,
                CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
                CaptureRequest.CONTROL_AWB_MODE_SHADE};
    }

    private int[] antiModes() {
        return new int[]{CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_OFF,
                CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_50HZ, CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_60HZ};
    }

    private int shutterMsToProgress(long ns) {
        double ms = ns / 1_000_000.0;
        return Math.max(1, Math.min(100, (int) Math.round(ms)));
    }

    private double progressToShutterMs(int p) { return Math.max(1, p); }

    private void updateShutterLabel() {
        double ms = progressToShutterMs(Build.VERSION.SDK_INT >= 26 ? shutterBar.getProgress() : shutterBar.getProgress() + 1);
        shutterText.setText(String.format(Locale.US, "Shutter: %.2f ms (≈1/%.0f) (LIVE)", ms, 1000.0 / ms));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
