package com.opencamlink;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Range;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

final class CameraController {
    private static final String TAG = "OpenCamLink.Camera";
    private final Context context;
    private final VideoBroadcaster broadcaster;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private HandlerThread codecThread;
    private Handler codecHandler;

    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder request;
    private MediaCodec codec;
    private Surface codecSurface;
    private volatile Surface previewSurface;
    private String cameraId;
    private CameraCharacteristics characteristics;

    private int width = 1920;
    private int height = 1080;
    private int fps = 60;
    private int bitrate = 20_000_000;

    private float zoom = 1f;
    private boolean manualExposure = false;
    private int iso = 200;
    private long exposureNs = 8_333_333L;
    private int aeComp = 0;
    private int awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO;
    private boolean manualFocus = false;
    private float focusDistance = 0f;
    private int antiBanding = CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO;
    private boolean ois = true;
    private boolean eis = false;
    private Range<Integer> fpsRange;

    CameraController(Context context, VideoBroadcaster broadcaster) {
        this.context = context;
        this.broadcaster = broadcaster;
    }

    void configure(String cameraId, int width, int height, int fps, int bitrate) {
        this.cameraId = cameraId;
        this.width = width;
        this.height = height;
        this.fps = fps;
        this.bitrate = bitrate;
    }

    void setPreviewSurface(Surface surface) {
        previewSurface = surface;
        Handler h = cameraHandler;
        if (h != null) h.post(() -> {
            if (camera != null) createSession();
        });
    }

    @SuppressLint("MissingPermission")
    void start() throws Exception {
        cameraThread = new HandlerThread("OpenCamLink-Camera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        codecThread = new HandlerThread("OpenCamLink-Codec");
        codecThread.start();
        codecHandler = new Handler(codecThread.getLooper());

        CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        if (cameraId == null) cameraId = chooseDefaultCamera(cm);
        characteristics = cm.getCameraCharacteristics(cameraId);
        fpsRange = chooseFpsRange(characteristics, fps);

        setupCodec();
        cm.openCamera(cameraId, new CameraDevice.StateCallback() {
            @Override public void onOpened(CameraDevice c) {
                camera = c;
                createSession();
            }
            @Override public void onDisconnected(CameraDevice c) { c.close(); camera = null; }
            @Override public void onError(CameraDevice c, int error) { c.close(); camera = null; }
        }, cameraHandler);
    }

    private String chooseDefaultCamera(CameraManager cm) throws CameraAccessException {
        String first = cm.getCameraIdList()[0];
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
        }
        return first;
    }

    private Range<Integer> chooseFpsRange(CameraCharacteristics cc, int target) {
        try {
            Range<Integer>[] ranges = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            Range<Integer> best = null;
            if (ranges != null) {
                for (Range<Integer> r : ranges) {
                    if (r.getLower() == target && r.getUpper() == target) return r;
                    if (r.contains(target)) {
                        if (best == null || r.getLower() > best.getLower()) best = r;
                    }
                }
                if (best != null) return best;
                for (Range<Integer> r : ranges) {
                    if (best == null || Math.abs(r.getUpper() - target) < Math.abs(best.getUpper() - target)) best = r;
                }
            }
            return best;
        } catch (Exception ignored) { return null; }
    }

    private void setupCodec() throws Exception {
        MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        fmt.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
        try { fmt.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh); } catch (Exception ignored) { }
        try { fmt.setInteger(MediaFormat.KEY_LEVEL, MediaCodecInfo.CodecProfileLevel.AVCLevel42); } catch (Exception ignored) { }

        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        codec.setCallback(new MediaCodec.Callback() {
            @Override public void onInputBufferAvailable(MediaCodec codec, int index) { }
            @Override public void onOutputBufferAvailable(MediaCodec mc, int index, MediaCodec.BufferInfo info) {
                try {
                    ByteBuffer bb = mc.getOutputBuffer(index);
                    if (bb == null) return;
                    bb.position(info.offset);
                    bb.limit(info.offset + info.size);
                    byte[] data = new byte[info.size];
                    bb.get(data);
                    boolean config = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                    boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                    if (data.length > 0) broadcaster.publish(new Frame(info.presentationTimeUs, data, config, key));
                } finally {
                    mc.releaseOutputBuffer(index, false);
                }
            }
            @Override public void onError(MediaCodec codec, MediaCodec.CodecException e) { Log.e(TAG, "encoder error", e); }
            @Override public void onOutputFormatChanged(MediaCodec mc, MediaFormat format) {
                try {
                    ByteBuffer sps = format.getByteBuffer("csd-0");
                    ByteBuffer pps = format.getByteBuffer("csd-1");
                    if (sps != null) {
                        byte[] a = new byte[sps.remaining()]; sps.duplicate().get(a);
                        byte[] b = new byte[pps == null ? 0 : pps.remaining()];
                        if (pps != null) pps.duplicate().get(b);
                        byte[] both = new byte[a.length + b.length];
                        System.arraycopy(a, 0, both, 0, a.length);
                        System.arraycopy(b, 0, both, a.length, b.length);
                        broadcaster.publish(new Frame(0, both, true, true));
                    }
                } catch (Exception ignored) { }
            }
        }, codecHandler);
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codecSurface = codec.createInputSurface();
        broadcaster.setCodec(codec);
        codec.start();
    }

    private void createSession() {
        if (camera == null || codecSurface == null) return;
        try {
            if (session != null) {
                try { session.close(); } catch (Exception ignored) { }
                session = null;
            }

            request = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            List<Surface> outputs = new ArrayList<>();
            outputs.add(codecSurface);
            request.addTarget(codecSurface);

            Surface p = previewSurface;
            if (p != null && p.isValid()) {
                outputs.add(p);
                request.addTarget(p);
            }

            applyControls(request);
            camera.createCaptureSession(outputs, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    try { s.setRepeatingRequest(request.build(), null, cameraHandler); }
                    catch (CameraAccessException | IllegalArgumentException e) { Log.e(TAG, "repeat request", e); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { Log.e(TAG, "capture session configuration failed"); }
            }, cameraHandler);
        } catch (CameraAccessException | IllegalArgumentException e) {
            Log.e(TAG, "create session", e);
        }
    }

    private void applyControls(CaptureRequest.Builder b) {
        try { b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO); } catch (Exception ignored) { }
        try { if (fpsRange != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE, antiBanding); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.CONTROL_AWB_MODE, awbMode); } catch (Exception ignored) { }

        if (manualExposure) {
            int safeIso = clampIso(iso);
            long safeExposure = clampExposure(exposureNs);
            try { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.SENSOR_SENSITIVITY, safeIso); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, safeExposure); } catch (Exception ignored) { }
        } else {
            try { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, clampAeComp(aeComp)); } catch (Exception ignored) { }
        }

        if (manualFocus) {
            try { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF); } catch (Exception ignored) { }
            try { b.set(CaptureRequest.LENS_FOCUS_DISTANCE, clampFocus(focusDistance)); } catch (Exception ignored) { }
        } else {
            try { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO); } catch (Exception ignored) { }
        }

        try { b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                ois ? CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON : CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF); } catch (Exception ignored) { }
        try { b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                eis ? CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON : CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF); } catch (Exception ignored) { }

        try {
            Rect active = characteristics == null ? null : characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Float maxZoom = characteristics == null ? null : characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            if (active != null && maxZoom != null) {
                float z = Math.max(1f, Math.min(zoom, maxZoom));
                int cropW = (int) (active.width() / z);
                int cropH = (int) (active.height() / z);
                int left = active.centerX() - cropW / 2;
                int top = active.centerY() - cropH / 2;
                b.set(CaptureRequest.SCALER_CROP_REGION, new Rect(left, top, left + cropW, top + cropH));
            }
        } catch (Exception ignored) { }
    }

    void updateControls(boolean manualExposure, int iso, long exposureNs, int aeComp,
                        int awbMode, boolean manualFocus, float focusDistance, float zoom,
                        int antiBanding, boolean ois, boolean eis, int newBitrate) {
        Handler h = cameraHandler;
        if (h == null) return;
        h.post(() -> {
            CameraController.this.manualExposure = manualExposure;
            CameraController.this.iso = iso;
            CameraController.this.exposureNs = exposureNs;
            CameraController.this.aeComp = aeComp;
            CameraController.this.awbMode = awbMode;
            CameraController.this.manualFocus = manualFocus;
            CameraController.this.focusDistance = focusDistance;
            CameraController.this.zoom = zoom;
            CameraController.this.antiBanding = antiBanding;
            CameraController.this.ois = ois;
            CameraController.this.eis = eis;

            if (newBitrate != bitrate && codec != null) {
                try {
                    Bundle params = new Bundle();
                    params.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, newBitrate);
                    codec.setParameters(params);
                    bitrate = newBitrate;
                    Log.i(TAG, "live bitrate changed to " + newBitrate);
                } catch (Exception e) { Log.w(TAG, "live bitrate update failed", e); }
            }

            if (request != null && session != null) {
                applyControls(request);
                try { session.setRepeatingRequest(request.build(), null, cameraHandler); }
                catch (Exception e) { Log.w(TAG, "control update failed", e); }
            }
        });
    }

    private int clampIso(int value) {
        try {
            Range<Integer> r = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            return r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
        } catch (Exception ignored) { return value; }
    }

    private long clampExposure(long value) {
        try {
            Range<Long> r = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            long v = r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
            long frameLimit = (long) (1_000_000_000L / Math.max(1, fps) * 0.98);
            return Math.min(v, frameLimit);
        } catch (Exception ignored) { return value; }
    }

    private int clampAeComp(int value) {
        try {
            Range<Integer> r = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            return r == null ? value : Math.max(r.getLower(), Math.min(value, r.getUpper()));
        } catch (Exception ignored) { return value; }
    }

    private float clampFocus(float value) {
        try {
            Float max = characteristics.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
            if (max == null || max <= 0f) return 0f;
            return Math.max(0f, Math.min(value, max));
        } catch (Exception ignored) { return value; }
    }

    void stop() {
        try { if (session != null) session.close(); } catch (Exception ignored) { }
        session = null;
        try { if (camera != null) camera.close(); } catch (Exception ignored) { }
        camera = null;
        try { if (codec != null) codec.stop(); } catch (Exception ignored) { }
        try { if (codec != null) codec.release(); } catch (Exception ignored) { }
        codec = null;
        codecSurface = null;
        broadcaster.setCodec(null);
        if (cameraThread != null) { cameraThread.quitSafely(); cameraThread = null; }
        if (codecThread != null) { codecThread.quitSafely(); codecThread = null; }
        cameraHandler = null;
        codecHandler = null;
    }
}
