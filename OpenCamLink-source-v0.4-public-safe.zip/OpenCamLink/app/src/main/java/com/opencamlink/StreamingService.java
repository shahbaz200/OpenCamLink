package com.opencamlink;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CaptureRequest;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Surface;

public class StreamingService extends Service {
    public static final String ACTION_START = "com.opencamlink.START";
    public static final String ACTION_RESTART = "com.opencamlink.RESTART";
    public static final String ACTION_STOP = "com.opencamlink.STOP";
    public static final String ACTION_UPDATE = "com.opencamlink.UPDATE";

    private static final String TAG = "OpenCamLink.Service";
    private static final String CHANNEL = "streaming";

    private final VideoBroadcaster broadcaster = new VideoBroadcaster();
    private final LocalBinder binder = new LocalBinder();
    private CameraController camera;
    private CompatServer server;
    private NsdAdvertiser nsd;
    private Surface previewSurface;
    private volatile boolean running;

    public final class LocalBinder extends Binder {
        public StreamingService getService() { return StreamingService.this; }
    }

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopEverything(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_UPDATE.equals(action)) {
            applySettingsLive();
            return START_STICKY;
        }

        startForeground(47, buildNotification());

        if (ACTION_RESTART.equals(action)) {
            stopEverything(false);
            startEverything();
            return START_STICKY;
        }

        if (!running) startEverything();
        return START_STICKY;
    }

    public boolean isRunning() { return running; }

    public void setPreviewSurface(Surface surface) {
        previewSurface = surface;
        if (camera != null) camera.setPreviewSurface(surface);
    }

    public void clearPreviewSurface(Surface surface) {
        if (previewSurface == surface) {
            previewSurface = null;
            if (camera != null) camera.setPreviewSurface(null);
        }
    }

    private void startEverything() {
        try {
            SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
            int port = p.getInt("port", 4747);
            int fps = p.getInt("fps", 60);
            int bitrate = p.getInt("bitrate", 20_000_000);
            String cameraId = p.getString("camera_id", null);

            camera = new CameraController(this, broadcaster);
            camera.configure(cameraId, 1920, 1080, fps, bitrate);
            camera.setPreviewSurface(previewSurface);
            camera.start();
            applySettingsLive();

            server = new CompatServer(port, broadcaster);
            server.start();
            nsd = new NsdAdvertiser(this);
            nsd.start(port);
            running = true;
            Log.i(TAG, "streaming server started on port " + port);
        } catch (Exception e) {
            Log.e(TAG, "failed to start", e);
            stopEverything(true);
            stopSelf();
        }
    }

    public void applySettingsLive() {
        if (camera == null) return;
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        boolean manualExposure = p.getBoolean("manual_exposure", false);
        int iso = p.getInt("iso", 200);
        long exposureNs = p.getLong("exposure_ns", 8_333_333L);
        int aeComp = p.getInt("ae_comp", 0);
        int awb = p.getInt("awb", CaptureRequest.CONTROL_AWB_MODE_AUTO);
        boolean manualFocus = p.getBoolean("manual_focus", false);
        float focusDistance = p.getFloat("focus_distance", 0f);
        float zoom = p.getFloat("zoom", 1f);
        int antibanding = p.getInt("antibanding", CaptureRequest.CONTROL_AE_ANTIBANDING_MODE_AUTO);
        boolean ois = p.getBoolean("ois", true);
        boolean eis = p.getBoolean("eis", false);
        int bitrate = p.getInt("bitrate", 20_000_000);
        camera.updateControls(manualExposure, iso, exposureNs, aeComp, awb, manualFocus,
                focusDistance, zoom, antibanding, ois, eis, bitrate);
    }

    private void stopEverything(boolean removeForeground) {
        running = false;
        if (nsd != null) { nsd.stop(); nsd = null; }
        if (server != null) { server.stop(); server = null; }
        if (camera != null) { camera.stop(); camera = null; }
        broadcaster.closeAll();
        if (removeForeground) {
            try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        }
    }

    @Override public void onDestroy() {
        stopEverything(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Camera streaming", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("OpenCam Link")
                .setContentText("1080p camera server is running")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();
    }
}
